# ULTIMATE FIGMA MAKE PROMPT – SMIT OFFICIAL WEBSITE

Act as an award-winning UX/UI designer, branding expert, and creative director from a world-class digital agency. Your mission is to create the official website for **SMIT – Saliou Mines Industries & Techniques**, a prestigious Senegalese company based in Bayakh, Diender, Senegal.

This must NOT look like a template. It must look like a premium website built by an international digital agency for a leading construction, mining, real estate, and infrastructure company.

The website should immediately inspire trust, prestige, power, innovation, reliability, and professionalism.

Design a complete responsive website ready for real-world deployment with exceptional UI/UX, world-class typography, smooth animations, premium layouts, and modern interactions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMPANY INFORMATION

Company Name:
SMIT – Saliou Mines Industries & Techniques

Headquarters:
Bayakh, Diender, Senegal

Founder & CEO:
Mr. Saliou Mbaye

Executive Assistant:
Astou Mbaye

Business Activities:

• Earthmoving
• Civil Engineering
• Heavy Equipment Rental
• Bulldozer Rental
• Excavator Rental
• Wheel Loader Rental
• Road Preparation
• Land Development
• Sand Mining
• Sand Extraction
• Sand Sales
• Construction Materials Supply
• Real Estate
• Land Sales
• Property Development

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ABOUT THE COMPANY

SMIT is a respected Senegalese company recognized for delivering reliable solutions in construction, earthmoving, mining, heavy machinery rental, land development, and real estate.

The company has earned the trust of many public institutions, private companies, contractors, and local communities.

Founded by Mr. Saliou Mbaye, SMIT is committed to quality, innovation, integrity, sustainable development, and customer satisfaction.

Beyond business, the company contributes to local development through employment, infrastructure, entrepreneurship, and community engagement.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ABOUT THE CEO

Create a prestigious section dedicated to Mr. Saliou Mbaye.

Title:

President & Chief Executive Officer

Display a large professional portrait.

Include an elegant biography explaining that he is:

• One of the most respected entrepreneurs in the Bayakh–Diender area.
• A visionary leader committed to infrastructure and economic development.
• An entrepreneur who has collaborated with numerous government institutions and private organizations.
• A promoter of employment, local development, entrepreneurship, and community initiatives.
• A leader recognized for professionalism, integrity, and excellence.

Display:

Professional Signature

CEO Quote

Career Timeline

Leadership Philosophy

Community Commitment

Corporate Vision

Awards & Recognition

Large "Read Full Biography" button.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BRAND IDENTITY

Primary Color

Deep Green (#0A7A3D)

Secondary Green

Forest Green (#045A2A)

Accent Green

Emerald (#0E9F6E)

White

#FFFFFF

Light Gray

#F7F8FA

Dark Gray

#222222

Luxury Gold

#C7A54A (small accents only)

The website should feel premium, elegant, luxurious, and corporate.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TYPOGRAPHY

Poppins ExtraBold

Inter

Montserrat

Large headings.

Generous spacing.

Luxury visual hierarchy.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DESIGN STYLE

Modern

Corporate

Luxury

Industrial

Minimalist

Premium

Elegant

Large whitespace

Rounded cards

Soft shadows

Glassmorphism

Apple-inspired interface

High-end corporate style

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE THESE PAGES

HOME

ABOUT US

CEO

SERVICES

PROJECTS

MACHINERY

REAL ESTATE

LAND SALES

NEWS

CAREERS

CONTACT

REQUEST A QUOTE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOME PAGE

Create an immersive full-screen Hero.

Use a cinematic background video showing:

Bulldozers

Excavators

Heavy Machines

Road Construction

Sand Mining

Luxury Buildings

Construction Sites

Drone Footage

Overlay:

Dark gradient.

Headline:

Building Senegal's Future Through Excellence

Subtitle:

SMIT delivers world-class earthmoving, heavy equipment rental, construction support, land development, sand mining, and real estate solutions across Senegal.

Buttons:

Request a Quote

Explore Our Services

Watch Corporate Video

Animated Counters:

20+ Years Experience

500+ Projects

1000+ Clients

100+ Machines

24/7 Support

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SERVICES

Create premium service cards.

Each service opens a dedicated page.

Earthmoving

Heavy Equipment Rental

Bulldozer Rental

Excavator Rental

Wheel Loader Rental

Road Preparation

Land Development

Sand Mining

Sand Sales

Construction Material Supply

Real Estate

Land Sales

Property Development

Civil Engineering

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MACHINERY PAGE

Display a premium fleet showcase.

Each machine includes:

Large Photo

Specifications

Availability

Capacity

Rental Price Request

Book Now Button

Include:

Bulldozers

Excavators

Wheel Loaders

Dump Trucks

Graders

Compactors

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PROJECTS PAGE

Luxury portfolio.

Large image gallery.

Before / After slider.

Project categories:

Road Construction

Earthmoving

Government Projects

Real Estate

Land Development

Sand Mining

Infrastructure

Interactive filtering.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

REAL ESTATE PAGE

Display premium properties.

Land Development

Housing Projects

Commercial Projects

Investment Opportunities

Modern Property Cards.

Interactive Maps.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

LAND SALES PAGE

Residential Plots

Commercial Land

Industrial Land

Agricultural Land

Secure Documentation

Investment Advice

Large interactive map.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHY CHOOSE SMIT

Experience

Modern Equipment

Reliable Team

Professional Engineers

Competitive Pricing

Government Experience

Safety Standards

Customer Satisfaction

Community Commitment

Quality Assurance

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CSR & COMMUNITY IMPACT

Create a beautiful section showcasing SMIT's commitment to the community.

Include:

Youth Employment

Community Development

Infrastructure Support

Environmental Responsibility

Local Partnerships

Education Initiatives

Social Responsibility

Use elegant illustrations and professional imagery.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PARTNERS

Display an animated carousel of partner logos.

Government Institutions

Construction Companies

Banks

Private Companies

Municipalities

NGOs

Engineering Firms

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TESTIMONIALS

Luxury animated slider.

Government Officials

Private Companies

Construction Clients

Investors

Land Buyers

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

NEWS

Company News

Community Projects

Infrastructure Updates

Real Estate News

Corporate Announcements

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CAREERS

Join Our Team

Internships

Recruitment

Online Application

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

REQUEST A QUOTE

Beautiful premium form.

Select Service

Project Description

Location

Budget

Timeline

Attachments

Submit Button

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CONTACT

Interactive Google Map

Bayakh

Diender

Senegal

Phone

WhatsApp

Email

Business Hours

Social Links

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FOOTER

Dark Luxury Footer

Company

CEO

Services

Projects

Machinery

Real Estate

Gallery

News

Careers

FAQ

Contact

Privacy Policy

Terms of Service

Copyright

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EXTRA FEATURES

Sticky Navigation

Mega Menu

Dark Mode

Light Mode

Animated Counters

Parallax Effects

Framer Motion Animations

GSAP Scroll Effects

Smooth Scrolling

Apple-quality Micro Interactions

Premium Hover Effects

Loading Screen

Scroll Progress Bar

Floating WhatsApp Button

Floating Call Button

Back To Top Button

Search Bar

Language Switcher (French / English)

Cookie Banner

Newsletter

Accessibility (WCAG)

SEO Optimized

Fast Performance

Responsive Desktop

Responsive Tablet

Responsive Mobile

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

IMAGES

Generate realistic African industrial photography.

Professional workers wearing PPE.

Bulldozers.

Excavators.

Wheel Loaders.

Sand Mining.

Construction Sites.

Road Construction.

Luxury Buildings.

Modern Offices.

Land Development.

Drone Photography.

Golden Hour Lighting.

Ultra Realistic.

8K Quality.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FINAL OBJECTIVE

The final website must position SMIT as one of the most trusted and respected companies in Senegal in earthmoving, heavy equipment rental, sand mining, construction, real estate, and land development.

The website should be so premium that visitors immediately perceive SMIT as a major national company capable of handling large private and public projects.

Every section must communicate trust, prestige, leadership, innovation, safety, professionalism, and long-term credibility. The design should be visually stunning, modern, elegant, highly responsive, and ready for production.