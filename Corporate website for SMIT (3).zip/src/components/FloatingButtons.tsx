import { useState, useEffect } from 'react'
import { ArrowUp, Phone, MessageCircle } from 'lucide-react'

const WA_MSG = encodeURIComponent('Bonjour, je souhaite commander du sable de dune auprès de SMIT. Merci de me contacter.')
const WA_URL = `https://wa.me/221765979880?text=${WA_MSG}`

export default function FloatingButtons() {
  const [show, setShow] = useState(false)

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollTop = () => window.scrollTo({ top: 0, behavior: 'smooth' })

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 items-end">
      {/* WhatsApp — toujours visible */}
      <a
        href={WA_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center gap-0 overflow-hidden rounded-full shadow-xl transition-all hover:scale-110"
        style={{ background: '#25D366', boxShadow: '0 4px 20px rgba(37,211,102,0.45)' }}
        aria-label="Commander sur WhatsApp">
        {/* Label on hover */}
        <span className="max-w-0 group-hover:max-w-[160px] overflow-hidden transition-all duration-300 text-white text-xs font-bold whitespace-nowrap pl-0 group-hover:pl-4"
          style={{ fontFamily: 'var(--font-label)' }}>
          Commander du sable
        </span>
        <div className="w-14 h-14 flex items-center justify-center flex-shrink-0">
          <MessageCircle size={24} className="text-white" />
        </div>
      </a>

      {/* Phone */}
      <a
        href="tel:+221765979880"
        className="group flex items-center gap-0 overflow-hidden rounded-full shadow-xl transition-all hover:scale-110"
        style={{ background: 'var(--smit-green)', boxShadow: '0 4px 20px rgba(10,122,61,0.40)' }}
        aria-label="Appeler SMIT">
        <span className="max-w-0 group-hover:max-w-[130px] overflow-hidden transition-all duration-300 text-white text-xs font-bold whitespace-nowrap pl-0 group-hover:pl-4"
          style={{ fontFamily: 'var(--font-label)' }}>
          76 597 98 80
        </span>
        <div className="w-14 h-14 flex items-center justify-center flex-shrink-0">
          <Phone size={22} className="text-white" />
        </div>
      </a>

      {/* Back to top */}
      <button
        onClick={scrollTop}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-xl transition-all hover:scale-110 ${
          show ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        style={{ background: 'var(--smit-gold)', boxShadow: '0 4px 20px rgba(199,165,74,0.40)' }}
        aria-label="Retour en haut">
        <ArrowUp size={22} className="text-[#033D1C]" />
      </button>
    </div>
  )
}
