import { useState, useEffect, useRef } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X, ChevronDown, Search, Globe, Phone, MessageCircle } from 'lucide-react'
import smitLogo from '../imports/image.png'

const WA_MSG = encodeURIComponent('Bonjour, je souhaite commander du sable de dune auprès de SMIT. Merci de me contacter.')
const WA_URL = `https://wa.me/221765979880?text=${WA_MSG}`

const services = [
  { label: 'Terrassement', path: '/services' },
  { label: 'Location Engins Lourds', path: '/services' },
  { label: 'Préparation de Routes', path: '/services' },
  { label: 'Aménagement de Terrains', path: '/services' },
  { label: 'Sable & Carrières', path: '/services' },
  { label: 'Génie Civil', path: '/services' },
  { label: 'Matériaux de Construction', path: '/services' },
  { label: 'Immobilier', path: '/real-estate' },
]

const navLinks = [
  { label: 'Accueil',    path: '/' },
  { label: 'À propos',  path: '/about' },
  { label: 'PDG',       path: '/ceo' },
  { label: 'Services',  path: '/services', mega: true, children: services },
  { label: 'Projets',   path: '/projects' },
  { label: 'Machines',  path: '/machinery' },
  { label: 'Immobilier', path: '/real-estate' },
  { label: 'Terrains',  path: '/land-sales' },
  { label: 'Actualités', path: '/news' },
  { label: 'Carrières', path: '/careers' },
  { label: 'Contact',   path: '/contact' },
]

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [megaOpen, setMegaOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [lang, setLang] = useState<'EN' | 'FR'>('EN')
  const location = useLocation()
  const megaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMenuOpen(false)
    setMegaOpen(false)
  }, [location])

  const isHome = location.pathname === '/'
  const navBg = scrolled || !isHome ? 'bg-[#045A2A] shadow-lg' : 'bg-transparent'

  return (
    <>
      {/* Top Bar */}
      <div className="hidden lg:flex items-center justify-between px-8 py-2 bg-[#033D1C] text-white text-xs font-label">
        <div className="flex items-center gap-6">
          <a href="tel:+221765979880" className="flex items-center gap-1.5 hover:text-[#C7A54A] transition-colors">
            <Phone size={11} /> 76 597 98 80
          </a>
          <a href="tel:+221769934178" className="flex items-center gap-1.5 hover:text-[#C7A54A] transition-colors">
            <Phone size={11} /> 76 993 41 78
          </a>
          <span className="text-white/50">Bayakh, Diender · Sénégal</span>
          <span className="text-[#C7A54A]">Lun–Dim : 07h00 – 19h00</span>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setLang(l => l === 'EN' ? 'FR' : 'EN')}
            className="flex items-center gap-1 hover:text-[#C7A54A] transition-colors"
          >
            <Globe size={11} />
            {lang === 'EN' ? 'Français' : 'English'}
          </button>
          <a href={WA_URL} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-1.5 font-bold px-4 py-1 rounded-full text-white transition-colors hover:opacity-90"
            style={{ background: '#25D366', fontFamily: 'var(--font-label)' }}>
            <MessageCircle size={11} /> Commander du sable
          </a>
        </div>
      </div>

      {/* Main Nav */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled || !isHome ? 'top-0' : 'top-8'} ${navBg}`}
        style={{ fontFamily: 'var(--font-label)' }}
      >
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 flex-shrink-0">
            <img src={smitLogo} alt="SMIT Logo" className="h-12 lg:h-14 w-auto object-contain" />
            <div className="hidden sm:block">
              <div className="text-white font-heading font-extrabold text-lg leading-none">SMIT</div>
              <div className="text-[#C7A54A] text-[10px] tracking-widest uppercase leading-none mt-0.5">Saliou Mines Industries & Techniques</div>
            </div>
          </Link>

          {/* Desktop Links */}
          <div className="hidden xl:flex items-center gap-1">
            {navLinks.map(link => (
              link.mega ? (
                <div key={link.label} className="relative" ref={megaRef}>
                  <button
                    className={`flex items-center gap-1 px-3 py-2 text-sm font-medium transition-colors rounded-md ${
                      location.pathname.startsWith('/services') ? 'text-[#C7A54A]' : 'text-white hover:text-[#C7A54A]'
                    }`}
                    onMouseEnter={() => setMegaOpen(true)}
                    onMouseLeave={() => setMegaOpen(false)}
                    onClick={() => setMegaOpen(v => !v)}
                  >
                    {link.label}
                    <ChevronDown size={14} className={`transition-transform ${megaOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {megaOpen && (
                    <div
                      className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-64 bg-[#045A2A] rounded-2xl shadow-2xl border border-white/10 overflow-hidden z-50"
                      onMouseEnter={() => setMegaOpen(true)}
                      onMouseLeave={() => setMegaOpen(false)}
                    >
                      {link.children?.map(child => (
                        <Link
                          key={child.label}
                          to={child.path}
                          className="block px-5 py-3 text-sm text-white hover:bg-[#0A7A3D] hover:text-[#C7A54A] transition-colors border-b border-white/5 last:border-0"
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  key={link.label}
                  to={link.path}
                  className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    location.pathname === link.path ? 'text-[#C7A54A]' : 'text-white hover:text-[#C7A54A]'
                  }`}
                >
                  {link.label}
                </Link>
              )
            ))}
          </div>

          {/* Right actions */}
          <div className="hidden xl:flex items-center gap-3">
            <button
              onClick={() => setSearchOpen(v => !v)}
              className="text-white hover:text-[#C7A54A] transition-colors p-2"
            >
              <Search size={18} />
            </button>
            <a href="tel:+221765979880"
              className="flex items-center gap-1.5 text-white font-bold px-4 py-2.5 rounded-full text-sm hover:bg-white/10 transition-all border border-white/20"
              style={{ fontFamily: 'var(--font-label)' }}>
              <Phone size={14} /> Appeler
            </a>
            <a href={WA_URL} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1.5 font-bold px-5 py-2.5 rounded-full text-sm hover:opacity-90 transition-all hover:scale-105 shadow-lg text-white"
              style={{ background: '#25D366', fontFamily: 'var(--font-label)' }}>
              <MessageCircle size={15} /> Commander du sable
            </a>
          </div>

          {/* Mobile hamburger */}
          <button
            className="xl:hidden text-white p-2"
            onClick={() => setMenuOpen(v => !v)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Search bar */}
        {searchOpen && (
          <div className="border-t border-white/10 bg-[#033D1C] px-6 py-3">
            <div className="max-w-[1400px] mx-auto">
              <div className="relative">
                <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/50" />
                <input
                  autoFocus
                  type="text"
                  placeholder="Search services, projects, machinery…"
                  className="w-full bg-white/10 text-white placeholder-white/40 pl-10 pr-4 py-3 rounded-xl outline-none border border-white/10 focus:border-[#C7A54A] text-sm"
                />
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-[#033D1C] overflow-y-auto pt-20">
          <div className="absolute inset-0 african-pattern opacity-30 pointer-events-none" />
          <div className="relative px-6 py-6 space-y-1">
            {navLinks.map(link => (
              <Link
                key={link.label}
                to={link.path}
                className={`flex items-center justify-between px-5 py-3.5 rounded-xl text-base font-medium transition-colors ${
                  location.pathname === link.path
                    ? 'bg-[#0A7A3D] text-[#C7A54A]'
                    : 'text-white hover:bg-[#0A7A3D]/60 hover:text-[#C7A54A]'
                }`}
                style={{ fontFamily: 'var(--font-label)' }}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-6 space-y-3">
              <a href={WA_URL} target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-2.5 w-full py-4 rounded-2xl font-bold text-base text-white"
                style={{ background: '#25D366', fontFamily: 'var(--font-label)', boxShadow: '0 4px 20px rgba(37,211,102,0.35)' }}>
                <MessageCircle size={20} /> Commander du sable
              </a>
              <a href="tel:+221765979880"
                className="flex items-center justify-center gap-2.5 w-full py-4 rounded-2xl font-bold text-base border border-white/20 text-white"
                style={{ fontFamily: 'var(--font-label)' }}>
                <Phone size={18} /> 76 597 98 80
              </a>
              <a href="tel:+221769934178"
                className="flex items-center justify-center gap-2.5 w-full py-3 rounded-2xl font-medium text-sm border border-white/10 text-white/70"
                style={{ fontFamily: 'var(--font-label)' }}>
                <Phone size={16} /> 76 993 41 78
              </a>
            </div>
            <p className="text-center text-white/30 text-xs pt-4" style={{ fontFamily: 'var(--font-label)' }}>
              🇸🇳 SMIT · Bayakh, Diender · Lun–Dim 07h–19h
            </p>
          </div>
        </div>
      )}
    </>
  )
}
