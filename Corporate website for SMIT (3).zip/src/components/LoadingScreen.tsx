import { useEffect, useState } from 'react'
import smitLogo from '../imports/image.png'

export default function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0)
  const [fade, setFade] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            setFade(true)
            setTimeout(onDone, 600)
          }, 200)
          return 100
        }
        return p + Math.random() * 8 + 2
      })
    }, 80)
    return () => clearInterval(interval)
  }, [onDone])

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center transition-opacity duration-700 ${
        fade ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{ background: 'linear-gradient(135deg, #033D1C 0%, #0A7A3D 50%, #033D1C 100%)' }}
    >
      {/* Animated rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {[1, 2, 3].map(i => (
          <div
            key={i}
            className="absolute rounded-full border border-white/10"
            style={{
              width: `${i * 180}px`,
              height: `${i * 180}px`,
              animation: `pulse-ring ${1.5 + i * 0.5}s ease-out infinite`,
              animationDelay: `${i * 0.2}s`,
            }}
          />
        ))}
      </div>

      {/* Logo */}
      <div className="relative z-10 flex flex-col items-center gap-8">
        <img
          src={smitLogo}
          alt="SMIT"
          className="w-32 h-32 object-contain float-anim drop-shadow-2xl"
        />

        <div className="text-center">
          <h1
            className="text-white font-extrabold text-4xl tracking-tight"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            SMIT
          </h1>
          <p
            className="text-[#C7A54A] text-xs tracking-[0.3em] uppercase mt-1"
            style={{ fontFamily: 'var(--font-label)' }}
          >
            Saliou Mines Industries & Techniques
          </p>
        </div>

        {/* Progress bar */}
        <div className="w-64 h-1 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-100"
            style={{
              width: `${Math.min(progress, 100)}%`,
              background: 'linear-gradient(90deg, #0A7A3D, #C7A54A)',
            }}
          />
        </div>

        <p className="text-white/40 text-xs tracking-widest font-label">
          LOADING {Math.round(Math.min(progress, 100))}%
        </p>
      </div>
    </div>
  )
}
