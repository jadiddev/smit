import { useState, useEffect } from 'react'
import { Cookie, X } from 'lucide-react'

export default function CookieBanner() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const accepted = localStorage.getItem('smit-cookies')
    if (!accepted) setTimeout(() => setVisible(true), 2500)
  }, [])

  const accept = () => { localStorage.setItem('smit-cookies', '1'); setVisible(false) }

  if (!visible) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 lg:p-6">
      <div className="max-w-4xl mx-auto rounded-2xl shadow-2xl p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4"
        style={{ background: '#022D15', border: '1px solid rgba(212,168,83,0.25)' }}>
        <div className="flex items-start gap-4 flex-1">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(212,168,83,0.20)' }}>
            <Cookie size={20} style={{ color: '#E8C97A' }} />
          </div>
          <div>
            <p className="text-white font-medium text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
              Nous utilisons des cookies
            </p>
            <p className="text-xs mt-0.5 leading-relaxed" style={{ color: 'rgba(255,255,255,0.50)' }}>
              Nous utilisons des cookies pour améliorer votre expérience et analyser notre trafic.
              En cliquant sur "Accepter", vous consentez à notre utilisation des cookies.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          <button onClick={accept}
            className="font-bold px-5 py-2.5 rounded-full text-sm hover:opacity-90 transition-opacity text-[#022D15]"
            style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)', fontFamily: 'var(--font-label)' }}>
            Accepter
          </button>
          <button onClick={() => setVisible(false)}
            className="p-1 transition-colors hover:text-white"
            style={{ color: 'rgba(255,255,255,0.35)' }}>
            <X size={18} />
          </button>
        </div>
      </div>
    </div>
  )
}
