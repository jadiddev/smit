import { Link } from 'react-router-dom'
import { Phone, Mail, MapPin, Share2, MessageSquare, Globe } from 'lucide-react'
import smitLogo from '../imports/image.png'

const columns = [
  {
    title: 'Entreprise',
    links: [
      { label: 'À propos de SMIT', path: '/about' },
      { label: 'PDG – Saliou Mbaye', path: '/ceo' },
      { label: 'Notre mission', path: '/about' },
      { label: 'Carrières', path: '/careers' },
      { label: 'Actualités', path: '/news' },
    ],
  },
  {
    title: 'Services',
    links: [
      { label: 'Terrassement', path: '/services' },
      { label: 'Location d\'engins', path: '/services' },
      { label: 'Sable des Niayes', path: '/services' },
      { label: 'Routes & Pistes', path: '/services' },
      { label: 'Génie Civil', path: '/services' },
    ],
  },
  {
    title: 'Immobilier',
    links: [
      { label: 'Immobilier', path: '/real-estate' },
      { label: 'Vente de terrains', path: '/land-sales' },
      { label: 'Parc d\'engins', path: '/machinery' },
      { label: 'Projets réalisés', path: '/projects' },
      { label: 'Galerie', path: '/projects' },
    ],
  },
  {
    title: 'Légal',
    links: [
      { label: 'Politique de confidentialité', path: '/contact' },
      { label: 'Conditions d\'utilisation', path: '/contact' },
      { label: 'FAQ', path: '/contact' },
      { label: 'Contact', path: '/contact' },
      { label: 'Demander un devis', path: '/request-quote' },
    ],
  },
]

const socials = [
  { icon: Globe, label: 'Facebook', href: '#' },
  { icon: Share2, label: 'LinkedIn', href: '#' },
  { icon: MessageSquare, label: 'WhatsApp', href: '#' },
  { icon: Globe, label: 'YouTube', href: '#' },
]

export default function Footer() {
  return (
    <footer style={{ background: '#010E06', color: 'white' }}>
      {/* Newsletter */}
      <div style={{ background: 'linear-gradient(135deg, #022D15, #0A7A3D)', borderTop: '1px solid rgba(212,168,83,0.2)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-2xl">🇸🇳</span>
              <h3 className="text-2xl font-extrabold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
                Restez informé avec SMIT
              </h3>
            </div>
            <p className="text-white/60 text-sm">
              Abonnez-vous pour recevoir nos actualités, projets et opportunités.
            </p>
          </div>
          <div className="flex gap-3 w-full lg:w-auto">
            <input type="email" placeholder="Votre adresse e-mail"
              className="flex-1 lg:w-72 border border-white/15 text-white placeholder-white/30 px-4 py-3 rounded-xl outline-none text-sm"
              style={{ background: 'rgba(255,255,255,0.08)' }} />
            <button className="font-bold px-6 py-3 rounded-xl transition-colors text-sm flex-shrink-0 text-[#022D15]"
              style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)' }}>
              S'abonner
            </button>
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-6 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <img src={smitLogo} alt="SMIT" className="h-16 w-auto object-contain" />
              <div>
                <div className="font-extrabold text-xl text-white leading-none" style={{ fontFamily: 'var(--font-heading)' }}>SMIT</div>
                <div className="text-xs tracking-widest uppercase mt-0.5" style={{ color: '#E8C97A' }}>
                  Saliou Mines Industries & Techniques
                </div>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-6" style={{ color: 'rgba(255,255,255,0.45)' }}>
              Entreprise sénégalaise de référence dans le terrassement, les carrières de sable
              de dune des Niayes, la location d'engins et l'immobilier depuis 2004.
            </p>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-3">
                <MapPin size={15} className="flex-shrink-0 mt-0.5" style={{ color: '#E8C97A' }} />
                <span style={{ color: 'rgba(255,255,255,0.45)' }}>Bayakh, Diender, Région de Thiès, Sénégal</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone size={15} className="flex-shrink-0" style={{ color: '#E8C97A' }} />
                <a href="tel:+221770000000" style={{ color: 'rgba(255,255,255,0.45)' }}
                  className="hover:text-white transition-colors">+221 77 000 0000</a>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={15} className="flex-shrink-0" style={{ color: '#E8C97A' }} />
                <a href="mailto:contact@smit-senegal.com" style={{ color: 'rgba(255,255,255,0.45)' }}
                  className="hover:text-white transition-colors">contact@smit-senegal.com</a>
              </div>
            </div>
            <div className="flex items-center gap-3 mt-8">
              {socials.map(s => (
                <a key={s.label} href={s.href} aria-label={s.label}
                  className="w-9 h-9 rounded-full flex items-center justify-center transition-all group"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.10)' }}>
                  <s.icon size={15} className="transition-colors group-hover:text-[#022D15]"
                    style={{ color: 'rgba(255,255,255,0.45)' }} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {columns.map(col => (
            <div key={col.title}>
              <h4 className="font-bold text-xs uppercase tracking-widest mb-5" style={{ color: '#E8C97A', fontFamily: 'var(--font-label)' }}>
                {col.title}
              </h4>
              <ul className="space-y-3">
                {col.links.map(link => (
                  <li key={link.label}>
                    <Link to={link.path}
                      className="text-sm transition-colors hover:text-white hover-underline"
                      style={{ color: 'rgba(255,255,255,0.45)' }}>
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs"
          style={{ color: 'rgba(255,255,255,0.25)' }}>
          <p>© {new Date().getFullYear()} SMIT – Saliou Mines Industries & Techniques · Tous droits réservés · Bayakh, Sénégal 🇸🇳</p>
          <p>Conçu avec excellence · Zone des Niayes</p>
        </div>
      </div>
    </footer>
  )
}
