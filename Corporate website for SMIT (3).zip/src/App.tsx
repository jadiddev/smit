import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'

import LoadingScreen from './components/LoadingScreen'
import Navigation from './components/Navigation'
import Footer from './components/Footer'
import ScrollProgress from './components/ScrollProgress'
import FloatingButtons from './components/FloatingButtons'
import CookieBanner from './components/CookieBanner'

import Home from './pages/Home'
import About from './pages/About'
import CEO from './pages/CEO'
import Services from './pages/Services'
import Projects from './pages/Projects'
import Machinery from './pages/Machinery'
import RealEstate from './pages/RealEstate'
import LandSales from './pages/LandSales'
import News from './pages/News'
import Careers from './pages/Careers'
import Contact from './pages/Contact'
import RequestQuote from './pages/RequestQuote'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' })
  }, [pathname])
  return null
}

function AppShell() {
  return (
    <div className="min-h-screen">
      <ScrollToTop />
      <ScrollProgress />
      <Navigation />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/ceo" element={<CEO />} />
          <Route path="/services" element={<Services />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/machinery" element={<Machinery />} />
          <Route path="/real-estate" element={<RealEstate />} />
          <Route path="/land-sales" element={<LandSales />} />
          <Route path="/news" element={<News />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/request-quote" element={<RequestQuote />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      <Footer />
      <FloatingButtons />
      <CookieBanner />
    </div>
  )
}

export default function App() {
  const [loaded, setLoaded] = useState(false)

  return (
    <BrowserRouter>
      {!loaded && <LoadingScreen onDone={() => setLoaded(true)} />}
      {loaded && <AppShell />}
    </BrowserRouter>
  )
}
