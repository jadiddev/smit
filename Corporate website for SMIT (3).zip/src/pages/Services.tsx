import { Link } from 'react-router-dom'
import { ArrowRight, CheckCircle } from 'lucide-react'

const IMG = {
  terrassement: 'https://images.unsplash.com/photo-1630288214173-a119cf823388?w=900&h=600&fit=crop&auto=format',
  engins:       'https://images.unsplash.com/photo-1630288214117-5ebf6c9de343?w=900&h=600&fit=crop&auto=format',
  route:        'https://images.unsplash.com/photo-1766409873595-b75388463ce8?w=900&h=600&fit=crop&auto=format',
  terrain:      'https://images.unsplash.com/photo-1766409874040-d4b233e92089?w=900&h=600&fit=crop&auto=format',
  sable:        'https://images.unsplash.com/photo-1783578990149-8b91589a7b2c?w=900&h=600&fit=crop&auto=format',
  genie:        'https://images.unsplash.com/photo-1601979107535-46367552bc25?w=900&h=600&fit=crop&auto=format',
  materiaux:    'https://images.unsplash.com/photo-1714829732336-a11bc5a5cfd5?w=900&h=600&fit=crop&auto=format',
  immo:         'https://images.unsplash.com/photo-1783260606348-bb2deaa215a3?w=900&h=600&fit=crop&auto=format',
}

const services = [
  {
    icon: '🏗️', title: 'Terrassement',
    desc: 'Excavation, déblais, remblais et nivellement de grande envergure pour l\'infrastructure, le résidentiel et l\'industrie au Sénégal.',
    img: IMG.terrassement,
    features: ['Décapage et débroussaillage', 'Excavation en grande masse', 'Opérations de déblais/remblais', 'Stabilisation de talus', 'Tranchées et comblement'],
  },
  {
    icon: '🚜', title: 'Location d\'engins lourds',
    desc: 'Location courte et longue durée de bulldozers, pelles hydrauliques, chargeuses — avec opérateurs expérimentés sénégalais.',
    img: IMG.engins,
    features: ['Location de bulldozers', 'Location de pelles hydrauliques', 'Location de chargeuses', 'Location de camions bennes', 'Opérateur & support inclus'],
  },
  {
    icon: '🛣️', title: 'Préparation de routes',
    desc: 'Mise en forme, compactage et drainage pour tout type de voirie — routes nationales, pistes communales, voiries industrielles.',
    img: IMG.route,
    features: ['Préparation de sous-couche', 'Profilage et nivellement', 'Compactage mécanique', 'Système de drainage', 'Construction pistes d\'accès'],
  },
  {
    icon: '📐', title: 'Aménagement de terrains',
    desc: 'Préparation complète de terrains pour projets résidentiels, commerciaux et industriels — du débroussaillage à la viabilisation.',
    img: IMG.terrain,
    features: ['Défrichement et nettoyage', 'Décapage de la couche arable', 'Nivellement et planage', 'Bornage et délimitation', 'Préparation à la construction'],
  },
  {
    icon: '⛏️', title: 'Sable de dune – Carrières Niayes',
    desc: 'Extraction et vente de sable de dune de qualité supérieure depuis nos carrières de la zone des Niayes — livraison rapide sur tout le Sénégal.',
    img: IMG.sable,
    features: ['Extraction carrières propres', 'Sable calibré et certifié', 'Ventes en gros et détail', 'Logistique de livraison', 'Conformité réglementaire'],
  },
  {
    icon: '⚙️', title: 'Génie civil',
    desc: 'Services d\'ingénierie civile : études de terrain, conception drainage, fondations et planification d\'infrastructure.',
    img: IMG.genie,
    features: ['Études et relevés topographiques', 'Ingénierie du drainage', 'Ouvrages de soutènement', 'Préparation de fondations', 'Planification d\'infrastructure'],
  },
  {
    icon: '🧱', title: 'Fourniture de matériaux',
    desc: 'Approvisionnement en matériaux de construction : sable, graviers, remblai — pour projets de toutes tailles.',
    img: IMG.materiaux,
    features: ['Sable de construction', 'Granulats et graviers', 'Matériaux de remblai', 'Livraison sur chantier', 'Logistique intégrée'],
  },
  {
    icon: '🏢', title: 'Immobilier & Foncier',
    desc: 'Terrains viabilisés, projets résidentiels, foncier commercial avec documentation légale complète au Sénégal.',
    img: IMG.immo,
    features: ['Développement de lotissements', 'Parcelles résidentielles', 'Foncier commercial', 'Conseil en investissement', 'Documentation juridique'],
  },
]

export default function Services() {
  return (
    <div className="pt-28" style={{ background: 'var(--smit-cream)' }}>
      {/* Hero */}
      <section className="py-24 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #022D15 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0"
          style={{ backgroundImage: `url(${IMG.terrassement})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.18 }} />
        <div className="absolute inset-0 african-pattern opacity-50" />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <div className="text-4xl mb-4">⚙️</div>
          <p className="text-[#E8C97A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>
            Nos expertises
          </p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
            Nos Services
          </h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto leading-relaxed">
            Des solutions industrielles et foncières complètes, adaptées aux réalités du terrain sénégalais,
            livrées avec excellence et dans les délais convenus.
          </p>
        </div>
      </section>

      {/* Liste services */}
      <section className="py-20" style={{ background: 'var(--smit-cream)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="space-y-16">
            {services.map((s, i) => (
              <div key={s.title}
                className={`bg-white rounded-3xl overflow-hidden shadow-premium flex flex-col lg:flex-row ${i % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="lg:w-1/2 min-h-[320px] bg-[#0A7A3D] relative"
                  style={{ backgroundImage: `url(${s.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(212,168,83,0.08), rgba(2,29,15,0.25))' }} />
                </div>
                <div className="lg:w-1/2 p-10 lg:p-14 flex flex-col justify-center">
                  <div className="text-4xl mb-4">{s.icon}</div>
                  <h2 className="text-3xl font-extrabold text-[#1A1F14] mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                    {s.title}
                  </h2>
                  <p className="text-[#6B7264] leading-relaxed mb-8">{s.desc}</p>
                  <ul className="space-y-2 mb-8">
                    {s.features.map(f => (
                      <li key={f} className="flex items-center gap-3 text-sm text-[#6B7264]">
                        <CheckCircle size={16} className="text-[#0A7A3D] flex-shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link to="/request-quote"
                    className="inline-flex items-center gap-2 text-white font-bold px-8 py-4 rounded-full hover:scale-105 transition-all self-start"
                    style={{ background: 'linear-gradient(135deg, #0A7A3D, #045A2A)' }}>
                    Demander un devis <ArrowRight size={18} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
