import { Link } from 'react-router-dom'
import { ArrowRight, CheckCircle, Gauge, Layers, Clock } from 'lucide-react'

const IMG = {
  bulldozer:  'https://images.unsplash.com/photo-1630288214117-5ebf6c9de343?w=800&h=500&fit=crop&auto=format',
  pelle:      'https://images.unsplash.com/photo-1630288214173-a119cf823388?w=800&h=500&fit=crop&auto=format',
  chargeuse:  'https://images.unsplash.com/photo-1664312616511-81fe2e745cb3?w=800&h=500&fit=crop&auto=format',
  camion:     'https://images.unsplash.com/photo-1714829732336-a11bc5a5cfd5?w=800&h=500&fit=crop&auto=format',
  grader:     'https://images.unsplash.com/photo-1766409873595-b75388463ce8?w=800&h=500&fit=crop&auto=format',
  compacteur: 'https://images.unsplash.com/photo-1653315917834-04a6d84e132e?w=800&h=500&fit=crop&auto=format',
}

const machines = [
  {
    name: 'Bulldozer Caterpillar D8T',
    type: 'Bulldozer', img: IMG.bulldozer, available: true, badge: 'Performant',
    specs: ['Poids opérationnel : 38 500 kg', 'Puissance : 310 CV', 'Capacité lame : 10,5 m³', 'Largeur chenille : 560 mm'],
  },
  {
    name: 'Pelle hydraulique Komatsu PC400',
    type: 'Pelle hydraulique', img: IMG.pelle, available: true, badge: 'Plus demandé',
    specs: ['Poids opérationnel : 41 500 kg', 'Puissance : 296 CV', 'Capacité godet : 1,9 m³', 'Prof. fouille max : 7,7 m'],
  },
  {
    name: 'Chargeuse Volvo L150H',
    type: 'Chargeuse', img: IMG.chargeuse, available: true, badge: 'Disponible',
    specs: ['Poids opérationnel : 25 100 kg', 'Puissance : 228 CV', 'Capacité godet : 4,6 m³', 'Charge basculante : 15 500 kg'],
  },
  {
    name: 'Camion-benne Caterpillar 773G',
    type: 'Camion-benne', img: IMG.camion, available: false, badge: 'En mission',
    specs: ['Charge utile : 55 000 kg', 'Puissance : 760 CV', 'Volume caisse : 35,3 m³', 'Vitesse max : 65 km/h'],
  },
  {
    name: 'Niveleuse John Deere 872GP',
    type: 'Niveleuse', img: IMG.grader, available: true, badge: 'Routes',
    specs: ['Poids opérationnel : 20 400 kg', 'Puissance : 235 CV', 'Largeur lame : 4,3 m', 'Force de traction max : 128 kN'],
  },
  {
    name: 'Compacteur Dynapac CA6000',
    type: 'Compacteur', img: IMG.compacteur, available: true, badge: 'Disponible',
    specs: ['Poids opérationnel : 19 700 kg', 'Puissance : 193 CV', 'Largeur tambour : 2,13 m', 'Fréquence : 28/33 Hz'],
  },
]

export default function Machinery() {
  return (
    <div className="pt-28" style={{ background: 'var(--smit-cream)' }}>
      {/* Hero */}
      <section className="py-24 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #011A0E 0%, #033D1C 100%)' }}>
        <div className="absolute inset-0"
          style={{ backgroundImage: `url(${IMG.bulldozer})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.20 }} />
        <div className="absolute inset-0 african-pattern opacity-40" />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <div className="text-4xl mb-4">🚜</div>
          <p className="text-[#E8C97A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>
            Notre flotte
          </p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
            Parc d'Engins Premium
          </h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto">
            SMIT exploite 100+ engins modernes entretenus aux standards internationaux —
            disponibles à la location avec opérateurs sénégalais expérimentés.
          </p>
        </div>
      </section>

      {/* Stats barre */}
      <section style={{ background: '#0A7A3D', borderBottom: '1px solid rgba(212,168,83,0.2)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-3 divide-x divide-white/10">
            {[
              { icon: Layers, val: '100+', label: 'Engins au total' },
              { icon: Gauge, val: '98%', label: 'Taux de disponibilité' },
              { icon: Clock, val: '24/7', label: 'Assistance terrain' },
            ].map(s => (
              <div key={s.label} className="flex items-center gap-4 px-8 py-8">
                <s.icon size={32} className="text-[#E8C97A] flex-shrink-0" />
                <div>
                  <div className="text-white font-extrabold text-3xl" style={{ fontFamily: 'var(--font-heading)' }}>{s.val}</div>
                  <div className="text-white/60 text-sm">{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Catalogue */}
      <section className="py-20" style={{ background: 'var(--smit-cream)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {machines.map(m => (
              <div key={m.name}
                className="bg-white rounded-3xl overflow-hidden shadow-premium hover:-translate-y-2 hover:shadow-warm transition-all duration-300 group">
                <div className="h-56 relative bg-[#0A7A3D]"
                  style={{ backgroundImage: `url(${m.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(212,168,83,0.05), rgba(2,29,15,0.30))' }} />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className="text-xs font-bold px-3 py-1.5 rounded-full text-[#022D15]"
                      style={{ background: 'linear-gradient(135deg, #E8C97A, #C7A54A)', fontFamily: 'var(--font-label)' }}>
                      {m.type}
                    </span>
                    <span className="text-xs bg-white/15 backdrop-blur-sm text-white font-bold px-3 py-1.5 rounded-full border border-white/25">
                      {m.badge}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4">
                    <span className={`text-xs font-bold px-3 py-1.5 rounded-full ${m.available ? 'bg-[#0E9F6E] text-white' : 'bg-[#E2E4DC] text-[#6B7264]'}`}>
                      {m.available ? '● Disponible' : '● En mission'}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-extrabold text-base text-[#1A1F14] mb-4" style={{ fontFamily: 'var(--font-heading)' }}>{m.name}</h3>
                  <ul className="space-y-2 mb-6">
                    {m.specs.map(spec => (
                      <li key={spec} className="flex items-center gap-2 text-sm text-[#6B7264]">
                        <CheckCircle size={14} className="text-[#0A7A3D] flex-shrink-0" />
                        {spec}
                      </li>
                    ))}
                  </ul>
                  <Link to="/request-quote"
                    className="w-full flex items-center justify-center gap-2 text-white font-bold py-3 rounded-xl hover:opacity-90 transition-opacity text-sm"
                    style={{ background: 'linear-gradient(135deg, #0A7A3D, #045A2A)' }}>
                    Réserver maintenant <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
