import { Link } from 'react-router-dom'
import { ArrowRight, Quote, Award, Briefcase, Heart, Star } from 'lucide-react'

const IMG = {
  ingenieur:  'https://images.unsplash.com/photo-1601979107535-46367552bc25?w=700&h=900&fit=crop&auto=format',
  ouvriers:   'https://images.unsplash.com/photo-1644778055925-cf45809c2c17?w=900&h=600&fit=crop&auto=format',
  savanna:    'https://images.unsplash.com/photo-1766409874040-d4b233e92089?w=900&h=600&fit=crop&auto=format',
  chantier:   'https://images.unsplash.com/photo-1630288214173-a119cf823388?w=900&h=600&fit=crop&auto=format',
}

const timeline = [
  { year: '2004', title: 'Fondation de SMIT', desc: 'Création de SMIT à Bayakh, Diender, avec pour mission de valoriser les ressources de la zone des Niayes.' },
  { year: '2007', title: 'Premier contrat gouvernemental', desc: 'Premier grand marché public de terrassement, établissant la réputation de SMIT auprès des institutions.' },
  { year: '2010', title: 'Ouverture des carrières', desc: 'Lancement de l\'exploitation industrielle de sable de dune — une première dans la zone des Niayes.' },
  { year: '2014', title: 'Expansion de la flotte', desc: 'Investissement dans 50+ engins modernes pour répondre à la demande croissante du marché sénégalais.' },
  { year: '2017', title: 'Lancement immobilier', desc: 'Création du pôle immobilier et vente de terrains — nouvelle dimension de SMIT.' },
  { year: '2024', title: 'Reconnaissance nationale', desc: 'SMIT compte 1 000+ clients satisfaits et est reconnu parmi les leaders industriels du Sénégal.' },
]

const philosophy = [
  { icon: Award, title: 'Vision stratégique', desc: 'Anticiper les besoins du marché sénégalais et positionner SMIT comme un acteur de référence national.' },
  { icon: Heart, title: 'Engagement communautaire', desc: 'Investir dans les hommes et les femmes de Bayakh et Diender — l\'entreprise au service de son territoire.' },
  { icon: Briefcase, title: 'Excellence opérationnelle', desc: 'Exiger les plus hauts standards dans chaque projet, chaque livraison, chaque service.' },
  { icon: Star, title: 'Esprit entrepreneurial', desc: 'Transformer les opportunités en réalisations concrètes pour le développement du Sénégal.' },
]

export default function CEO() {
  return (
    <div className="pt-28" style={{ background: 'var(--smit-cream)' }}>
      {/* Hero */}
      <section className="py-24 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #011A0E 0%, #033D1C 100%)' }}>
        <div className="absolute inset-0"
          style={{ backgroundImage: `url(${IMG.savanna})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.15 }} />
        <div className="absolute inset-0 african-pattern opacity-50" />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Photo */}
            <div className="relative">
              <div className="absolute -inset-5 rounded-[40px] opacity-20" style={{ background: 'linear-gradient(135deg, #C7A54A, #0A7A3D)' }} />
              <div className="relative rounded-3xl overflow-hidden aspect-[3/4] max-w-sm mx-auto lg:mx-0 bg-[#033D1C]"
                style={{ backgroundImage: `url(${IMG.ingenieur})`, backgroundSize: 'cover', backgroundPosition: 'center top' }}>
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, #011A0E 0%, transparent 55%)' }} />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="text-[#E8C97A] text-xs tracking-widest uppercase font-bold mb-1" style={{ fontFamily: 'var(--font-label)' }}>
                    Fondateur & PDG
                  </div>
                  <div className="text-white text-2xl font-extrabold" style={{ fontFamily: 'var(--font-heading)' }}>Saliou Mbaye</div>
                  <div className="text-white/60 text-sm mt-1">Président-Directeur Général · SMIT</div>
                </div>
              </div>
              <div className="absolute -bottom-4 -right-4 rounded-2xl p-5 shadow-2xl text-center"
                style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)' }}>
                <div className="text-[#022D15] font-extrabold text-3xl" style={{ fontFamily: 'var(--font-heading)' }}>🇸🇳</div>
                <div className="text-[#022D15] text-xs font-bold uppercase tracking-widest mt-1">Entreprise<br />Sénégalaise</div>
              </div>
            </div>

            {/* Bio */}
            <div>
              <div className="w-12 h-1 rounded-full mb-6" style={{ background: 'linear-gradient(90deg, #E8C97A, #C7A54A)' }} />
              <p className="text-[#E8C97A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>
                Profil PDG
              </p>
              <h1 className="text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                Saliou Mbaye
                <span className="block text-3xl mt-2" style={{
                  background: 'linear-gradient(135deg, #E8C97A, #C7A54A)',
                  WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
                }}>
                  PDG & Fondateur · SMIT
                </span>
              </h1>
              <div className="space-y-4 text-white/70 text-lg leading-relaxed">
                <p>
                  M. Saliou Mbaye est l'un des entrepreneurs les plus respectés de la zone
                  Bayakh–Diender. Pionnier de l'industrialisation des Niayes, il a consacré
                  plus de vingt ans à bâtir une entreprise qui fait la fierté du Sénégal.
                </p>
                <p>
                  Sous sa direction, SMIT est devenu un acteur de référence dans le terrassement,
                  les carrières de sable, la location d'engins lourds et l'immobilier — servant
                  les institutions publiques, les grandes entreprises de BTP et des milliers
                  de clients individuels à travers le pays.
                </p>
                <p>
                  Son engagement envers l'intégrité, la qualité et l'innovation lui a valu
                  la reconnaissance des autorités gouvernementales, des partenaires privés
                  et des communautés de la zone des Niayes qu'il a contribué à développer.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Citation */}
      <section className="py-20 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0A7A3D, #022D15)' }}>
        <div className="absolute inset-0 african-pattern opacity-40" />
        <div className="max-w-3xl mx-auto px-6 lg:px-10 text-center relative z-10">
          <div className="text-4xl mb-6">🇸🇳</div>
          <Quote size={44} className="text-[#E8C97A] mx-auto mb-6" />
          <blockquote className="text-3xl lg:text-4xl font-bold text-white leading-snug italic mb-8" style={{ fontFamily: 'var(--font-heading)' }}>
            "Nous ne déplaçons pas simplement la terre — nous construisons l'avenir du Sénégal,
            en valorisant nos ressources naturelles et en formant notre jeunesse."
          </blockquote>
          <p className="text-[#E8C97A] font-bold tracking-widest text-sm" style={{ fontFamily: 'var(--font-label)' }}>
            — SALIOU MBAYE, PDG · SMIT · BAYAKH, NIAYES
          </p>
        </div>
      </section>

      {/* Philosophie */}
      <section className="py-24 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="text-center mb-14">
            <div className="section-divider mx-auto mb-6" />
            <h2 className="text-4xl font-extrabold text-[#1A1F14]" style={{ fontFamily: 'var(--font-heading)' }}>
              Philosophie de leadership
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {philosophy.map(p => (
              <div key={p.title}
                className="bg-[#F5F6F0] rounded-3xl p-8 border border-[#E2E4DC] hover:border-[#0A7A3D] hover:shadow-green transition-all group text-center">
                <div className="w-16 h-16 rounded-2xl bg-white group-hover:bg-[#0A7A3D] flex items-center justify-center mx-auto mb-6 transition-colors shadow-sm">
                  <p.icon size={28} className="text-[#0A7A3D] group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-lg font-bold text-[#1A1F14] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{p.title}</h3>
                <p className="text-[#6B7264] text-sm leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline carrière */}
      <section className="py-24" style={{ background: 'var(--smit-cream)' }}>
        <div className="max-w-[900px] mx-auto px-6 lg:px-10">
          <div className="text-center mb-14">
            <div className="section-divider-sand mx-auto mb-6" />
            <h2 className="text-4xl font-extrabold text-[#1A1F14]" style={{ fontFamily: 'var(--font-heading)' }}>
              Parcours
            </h2>
          </div>
          <div className="space-y-6">
            {timeline.map((t, i) => (
              <div key={t.year} className="flex gap-6 items-start group">
                <div className="flex-shrink-0 flex flex-col items-center">
                  <div className="w-14 h-14 rounded-full border-2 border-[#0A7A3D] group-hover:bg-[#0A7A3D] flex items-center justify-center transition-all shadow-green">
                    <span className="text-[#0A7A3D] group-hover:text-white text-xs font-bold transition-colors" style={{ fontFamily: 'var(--font-label)' }}>
                      {t.year.slice(2)}
                    </span>
                  </div>
                  {i < timeline.length - 1 && <div className="w-px h-8 bg-[#E2E4DC] mt-2" />}
                </div>
                <div className="flex-1 pb-6">
                  <div className="text-[#B5803A] font-bold text-sm" style={{ fontFamily: 'var(--font-label)' }}>{t.year}</div>
                  <h4 className="text-[#1A1F14] font-bold text-lg mt-0.5 mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{t.title}</h4>
                  <p className="text-[#6B7264] text-sm leading-relaxed bg-white rounded-xl px-4 py-3 border border-[#E2E4DC]">{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Engagement communautaire */}
      <section className="py-24 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #022D15, #0A7A3D)' }}>
        <div className="absolute inset-0 african-pattern opacity-50" />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="w-12 h-1 rounded-full mb-6" style={{ background: 'linear-gradient(90deg, #E8C97A, #C7A54A)' }} />
              <h2 className="text-4xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                Engagement communautaire
              </h2>
              <p className="text-white/70 text-lg leading-relaxed mb-6">
                Au-delà de la réussite commerciale de SMIT, M. Mbaye est profondément engagé
                dans le développement de la zone des Niayes. Il a personnellement soutenu
                des programmes d'emploi des jeunes, financé des infrastructures scolaires
                et participé au développement des communautés de Bayakh et Diender.
              </p>
              <p className="text-white/70 text-lg leading-relaxed mb-8">
                Sa vision dépasse le business : construire une main-d'œuvre qualifiée, prospère
                et durable qui portera l'économie sénégalaise pour les générations futures.
              </p>
              <Link to="/contact"
                className="inline-flex items-center gap-2 font-bold px-8 py-4 rounded-full hover:scale-105 transition-all"
                style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)', color: '#022D15' }}>
                Contacter SMIT <ArrowRight size={18} />
              </Link>
            </div>
            <div className="rounded-3xl overflow-hidden aspect-video bg-[#033D1C]"
              style={{ backgroundImage: `url(${IMG.ouvriers})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
              <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(212,168,83,0.05), rgba(2,29,15,0.20))' }} />
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
