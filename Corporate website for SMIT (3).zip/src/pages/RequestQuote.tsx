import { useState } from 'react'
import { CheckCircle, ArrowRight } from 'lucide-react'

const services = [
  'Earthmoving', 'Bulldozer Rental', 'Excavator Rental', 'Wheel Loader Rental',
  'Road Preparation', 'Land Development', 'Sand Mining', 'Sand Purchase',
  'Construction Materials', 'Real Estate', 'Land Purchase', 'Civil Engineering', 'Other',
]

const budgets = [
  'Under CFA 1,000,000', 'CFA 1M – 5M', 'CFA 5M – 20M', 'CFA 20M – 50M',
  'CFA 50M – 100M', 'CFA 100M+', 'To be discussed',
]

const timelines = [
  'Immediately', 'Within 1 month', '1 – 3 months', '3 – 6 months', '6 – 12 months', 'Flexible',
]

const whyItems = [
  '✓ Free, no-obligation quote within 24h',
  '✓ Expert team ready to advise',
  '✓ Transparent & competitive pricing',
  '✓ 20+ years industrial experience',
  '✓ 500+ successful projects delivered',
]

export default function RequestQuote() {
  const [step, setStep] = useState(1)
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({
    service: '',
    description: '',
    location: '',
    budget: '',
    timeline: '',
    name: '',
    company: '',
    email: '',
    phone: '',
    notes: '',
  })

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="pt-28">
      {/* Hero */}
      <section className="py-20 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #033D1C 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <p className="text-[#C7A54A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>Free Quote</p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Request a Quote</h1>
          <p className="text-white/70 text-xl max-w-2xl mx-auto">Tell us about your project and we'll provide a detailed, competitive quote within 24 hours — completely free and with no obligation.</p>
        </div>
      </section>

      <section className="py-20 bg-[#F7F8FA]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Sidebar */}
            <div className="space-y-6">
              <div className="bg-white rounded-3xl p-8 border border-[#E8EAF0] shadow-premium">
                <h3 className="text-xl font-extrabold text-[#222222] mb-5" style={{ fontFamily: 'var(--font-heading)' }}>Why Request a Quote?</h3>
                <ul className="space-y-3">
                  {whyItems.map(item => (
                    <li key={item} className="text-[#6B7280] text-sm flex items-start gap-2">
                      <CheckCircle size={14} className="text-[#0A7A3D] mt-0.5 flex-shrink-0" />
                      {item.replace('✓ ', '')}
                    </li>
                  ))}
                </ul>
              </div>

              <div style={{ background: 'linear-gradient(135deg, #033D1C, #0A7A3D)' }} className="rounded-3xl p-8 text-white">
                <div className="text-4xl mb-4">📞</div>
                <h4 className="text-xl font-bold mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Prefer to Call?</h4>
                <p className="text-white/70 text-sm mb-4">Our team is available Monday–Saturday, 08:00–18:00.</p>
                <a href="tel:+221770000000" className="block text-[#C7A54A] font-bold text-lg">+221 77 000 0000</a>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-2 bg-white rounded-3xl p-8 lg:p-12 border border-[#E8EAF0] shadow-premium">
              {submitted ? (
                <div className="text-center py-16">
                  <div className="w-20 h-20 rounded-full bg-[#0A7A3D]/10 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle size={40} className="text-[#0A7A3D]" />
                  </div>
                  <h3 className="text-3xl font-extrabold text-[#222222] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Quote Request Sent!</h3>
                  <p className="text-[#6B7280] text-lg mb-2">Thank you, <strong>{form.name}</strong>.</p>
                  <p className="text-[#6B7280]">Our team will review your project and send a detailed quote within 24 hours.</p>
                  <button onClick={() => { setSubmitted(false); setStep(1); setForm({ service: '', description: '', location: '', budget: '', timeline: '', name: '', company: '', email: '', phone: '', notes: '' }) }}
                    className="mt-8 inline-flex items-center gap-2 text-[#0A7A3D] font-bold hover:underline">
                    Submit Another Request <ArrowRight size={16} />
                  </button>
                </div>
              ) : (
                <>
                  {/* Step indicator */}
                  <div className="flex items-center gap-3 mb-10">
                    {[1, 2, 3].map(s => (
                      <div key={s} className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all ${step >= s ? 'bg-[#0A7A3D] text-white' : 'bg-[#F7F8FA] text-[#6B7280] border border-[#E8EAF0]'}`}>
                          {step > s ? <CheckCircle size={16} /> : s}
                        </div>
                        <span className={`text-xs font-bold hidden sm:block ${step >= s ? 'text-[#0A7A3D]' : 'text-[#6B7280]'}`} style={{ fontFamily: 'var(--font-label)' }}>
                          {s === 1 ? 'Service' : s === 2 ? 'Project Details' : 'Contact Info'}
                        </span>
                        {s < 3 && <div className={`h-px w-8 lg:w-16 ${step > s ? 'bg-[#0A7A3D]' : 'bg-[#E8EAF0]'}`} />}
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleSubmit}>
                    {/* Step 1: Service */}
                    {step === 1 && (
                      <div>
                        <h2 className="text-2xl font-extrabold text-[#222222] mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Select a Service</h2>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
                          {services.map(s => (
                            <button
                              key={s}
                              type="button"
                              onClick={() => set('service', s)}
                              className={`p-3.5 rounded-xl text-sm font-medium border-2 transition-all text-left ${form.service === s ? 'border-[#0A7A3D] bg-[#0A7A3D]/5 text-[#0A7A3D]' : 'border-[#E8EAF0] text-[#6B7280] hover:border-[#0A7A3D]'}`}
                            >
                              {s}
                            </button>
                          ))}
                        </div>
                        <button
                          type="button"
                          disabled={!form.service}
                          onClick={() => setStep(2)}
                          className="w-full bg-[#0A7A3D] text-white font-bold py-4 rounded-xl hover:bg-[#045A2A] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          Continue →
                        </button>
                      </div>
                    )}

                    {/* Step 2: Project details */}
                    {step === 2 && (
                      <div>
                        <h2 className="text-2xl font-extrabold text-[#222222] mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Project Details</h2>
                        <div className="space-y-5">
                          <div>
                            <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Project Description *</label>
                            <textarea required rows={4} placeholder="Describe your project in detail — scope, size, requirements, goals..." value={form.description} onChange={e => set('description', e.target.value)}
                              className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors resize-none" />
                          </div>
                          <div>
                            <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Project Location *</label>
                            <input required type="text" placeholder="City, region, or address in Senegal" value={form.location} onChange={e => set('location', e.target.value)}
                              className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                          </div>
                          <div>
                            <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Estimated Budget</label>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                              {budgets.map(b => (
                                <button key={b} type="button" onClick={() => set('budget', b)}
                                  className={`p-2.5 rounded-lg text-xs font-medium border transition-all ${form.budget === b ? 'border-[#0A7A3D] bg-[#0A7A3D]/5 text-[#0A7A3D]' : 'border-[#E8EAF0] text-[#6B7280] hover:border-[#0A7A3D]'}`}>
                                  {b}
                                </button>
                              ))}
                            </div>
                          </div>
                          <div>
                            <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Timeline</label>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                              {timelines.map(t => (
                                <button key={t} type="button" onClick={() => set('timeline', t)}
                                  className={`p-2.5 rounded-lg text-xs font-medium border transition-all ${form.timeline === t ? 'border-[#0A7A3D] bg-[#0A7A3D]/5 text-[#0A7A3D]' : 'border-[#E8EAF0] text-[#6B7280] hover:border-[#0A7A3D]'}`}>
                                  {t}
                                </button>
                              ))}
                            </div>
                          </div>
                          <div className="border-2 border-dashed border-[#E8EAF0] rounded-xl p-6 text-center text-sm text-[#6B7280] hover:border-[#0A7A3D] transition-colors cursor-pointer">
                            📎 Attach project documents, plans, or photos (optional)
                          </div>
                        </div>
                        <div className="flex gap-4 mt-8">
                          <button type="button" onClick={() => setStep(1)} className="flex-1 border-2 border-[#E8EAF0] text-[#6B7280] font-bold py-4 rounded-xl hover:border-[#0A7A3D] transition-colors">← Back</button>
                          <button type="button" onClick={() => setStep(3)} disabled={!form.description || !form.location} className="flex-1 bg-[#0A7A3D] text-white font-bold py-4 rounded-xl hover:bg-[#045A2A] transition-colors disabled:opacity-40">Continue →</button>
                        </div>
                      </div>
                    )}

                    {/* Step 3: Contact info */}
                    {step === 3 && (
                      <div>
                        <h2 className="text-2xl font-extrabold text-[#222222] mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Your Contact Information</h2>
                        <div className="space-y-5">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                              <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Full Name *</label>
                              <input required type="text" placeholder="Your full name" value={form.name} onChange={e => set('name', e.target.value)}
                                className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                            </div>
                            <div>
                              <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Company</label>
                              <input type="text" placeholder="Your company name" value={form.company} onChange={e => set('company', e.target.value)}
                                className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                            </div>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                              <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Email *</label>
                              <input required type="email" placeholder="your@email.com" value={form.email} onChange={e => set('email', e.target.value)}
                                className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                            </div>
                            <div>
                              <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Phone *</label>
                              <input required type="tel" placeholder="+221 77 000 0000" value={form.phone} onChange={e => set('phone', e.target.value)}
                                className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                            </div>
                          </div>
                          <div>
                            <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Additional Notes</label>
                            <textarea rows={3} placeholder="Any other information we should know..." value={form.notes} onChange={e => set('notes', e.target.value)}
                              className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors resize-none" />
                          </div>

                          {/* Summary */}
                          <div className="bg-[#F7F8FA] rounded-2xl p-5 border border-[#E8EAF0]">
                            <p className="font-bold text-sm text-[#222222] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Quote Summary</p>
                            <div className="grid grid-cols-2 gap-2 text-sm">
                              <div className="text-[#6B7280]">Service:</div><div className="text-[#222222] font-medium">{form.service}</div>
                              <div className="text-[#6B7280]">Location:</div><div className="text-[#222222] font-medium">{form.location}</div>
                              {form.budget && <><div className="text-[#6B7280]">Budget:</div><div className="text-[#222222] font-medium">{form.budget}</div></>}
                              {form.timeline && <><div className="text-[#6B7280]">Timeline:</div><div className="text-[#222222] font-medium">{form.timeline}</div></>}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-4 mt-8">
                          <button type="button" onClick={() => setStep(2)} className="flex-1 border-2 border-[#E8EAF0] text-[#6B7280] font-bold py-4 rounded-xl hover:border-[#0A7A3D] transition-colors">← Back</button>
                          <button type="submit" className="flex-1 bg-[#C7A54A] text-[#033D1C] font-bold py-4 rounded-xl hover:bg-[#D4B96A] transition-colors shadow-lg">
                            Submit Quote Request ✓
                          </button>
                        </div>
                      </div>
                    )}
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
