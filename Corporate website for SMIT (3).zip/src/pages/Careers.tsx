import { useState } from 'react'
import { MapPin, Clock, ArrowRight, Briefcase, GraduationCap, Users } from 'lucide-react'

const jobs = [
  { title: 'Senior Excavator Operator', dept: 'Operations', type: 'Full-time', location: 'Bayakh, Senegal', posted: '3 days ago' },
  { title: 'Civil Engineer', dept: 'Engineering', type: 'Full-time', location: 'Thiès Region', posted: '1 week ago' },
  { title: 'Heavy Equipment Mechanic', dept: 'Maintenance', type: 'Full-time', location: 'Bayakh, Senegal', posted: '2 weeks ago' },
  { title: 'Site Safety Officer', dept: 'QHSE', type: 'Full-time', location: 'Multiple Sites', posted: '3 days ago' },
  { title: 'Real Estate Sales Agent', dept: 'Real Estate', type: 'Full-time', location: 'Dakar / Thiès', posted: '5 days ago' },
  { title: 'Administrative Assistant', dept: 'Administration', type: 'Full-time', location: 'Bayakh, Senegal', posted: '1 week ago' },
  { title: 'Internship – Civil Engineering', dept: 'Engineering', type: 'Internship', location: 'Bayakh, Senegal', posted: '2 weeks ago' },
  { title: 'Junior Accountant', dept: 'Finance', type: 'Full-time', location: 'Bayakh, Senegal', posted: '4 days ago' },
]

const perks = [
  { icon: Briefcase, title: 'Career Growth', desc: 'Clear advancement paths and skill development programs.' },
  { icon: Users, title: 'Team Environment', desc: 'Work alongside Senegal\'s top industrial professionals.' },
  { icon: GraduationCap, title: 'Training Programs', desc: 'Continuous professional development and certifications.' },
]

const typeColor: Record<string, string> = {
  'Full-time': 'bg-[#0E9F6E]/10 text-[#0E9F6E]',
  'Internship': 'bg-[#C7A54A]/10 text-[#C7A54A]',
}

export default function Careers() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', position: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="pt-28">
      <section className="py-24 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #033D1C 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <p className="text-[#C7A54A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>Join Our Team</p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Careers at SMIT</h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto">Build your career with Senegal's leading industrial company. We offer opportunities across engineering, operations, real estate, and more.</p>
        </div>
      </section>

      {/* Perks */}
      <section className="py-16 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {perks.map(p => (
              <div key={p.title} className="text-center p-8 rounded-3xl border border-[#E8EAF0] hover:border-[#0A7A3D] hover:shadow-green transition-all group">
                <div className="w-16 h-16 rounded-2xl bg-[#F7F8FA] group-hover:bg-[#0A7A3D] flex items-center justify-center mx-auto mb-5 transition-colors">
                  <p.icon size={28} className="text-[#0A7A3D] group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-bold text-lg text-[#222222] mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{p.title}</h3>
                <p className="text-[#6B7280] text-sm leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Open positions */}
      <section className="py-20 bg-[#F7F8FA]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <h2 className="text-3xl font-extrabold text-[#222222] mb-10" style={{ fontFamily: 'var(--font-heading)' }}>Open Positions</h2>
          <div className="space-y-4">
            {jobs.map(j => (
              <div key={j.title} className="bg-white rounded-2xl p-6 border border-[#E8EAF0] hover:border-[#0A7A3D] hover:shadow-green transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-bold text-[#222222]" style={{ fontFamily: 'var(--font-heading)' }}>{j.title}</h3>
                    <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${typeColor[j.type]}`} style={{ fontFamily: 'var(--font-label)' }}>{j.type}</span>
                  </div>
                  <div className="flex flex-wrap gap-4 text-sm text-[#6B7280]">
                    <span className="flex items-center gap-1.5"><Briefcase size={13} />{j.dept}</span>
                    <span className="flex items-center gap-1.5"><MapPin size={13} />{j.location}</span>
                    <span className="flex items-center gap-1.5"><Clock size={13} />{j.posted}</span>
                  </div>
                </div>
                <button className="flex items-center gap-2 bg-[#0A7A3D] text-white font-bold px-6 py-2.5 rounded-full text-sm hover:bg-[#045A2A] transition-colors flex-shrink-0">
                  Apply Now <ArrowRight size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Application form */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-6 lg:px-10">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-[#222222]" style={{ fontFamily: 'var(--font-heading)' }}>Apply Online</h2>
            <p className="text-[#6B7280] mt-3">Don't see your role? Send us your CV and we'll get in touch.</p>
          </div>

          {submitted ? (
            <div className="bg-[#0A7A3D]/5 border border-[#0A7A3D] rounded-3xl p-10 text-center">
              <div className="text-5xl mb-4">✅</div>
              <h3 className="text-2xl font-bold text-[#0A7A3D] mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Application Submitted!</h3>
              <p className="text-[#6B7280]">Thank you. Our HR team will review your application and contact you shortly.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Full Name *</label>
                  <input required type="text" placeholder="Your full name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Email *</label>
                  <input required type="email" placeholder="your@email.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Phone</label>
                  <input type="tel" placeholder="+221 77 000 0000" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                    className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Position Desired</label>
                  <input type="text" placeholder="Role you're applying for" value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))}
                    className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Cover Letter / Message</label>
                <textarea rows={5} placeholder="Tell us about yourself and why you want to join SMIT..." value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                  className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors resize-none" />
              </div>
              <div className="border-2 border-dashed border-[#E8EAF0] rounded-xl p-6 text-center text-sm text-[#6B7280] hover:border-[#0A7A3D] transition-colors cursor-pointer">
                📎 Click to upload your CV (PDF, DOC – Max 5MB)
              </div>
              <button type="submit" className="w-full bg-[#0A7A3D] text-white font-bold py-4 rounded-xl hover:bg-[#045A2A] transition-colors text-base">
                Submit Application
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  )
}
