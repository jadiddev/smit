import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

const categories = ['Tous', 'Routes', 'Terrassement', 'Gouvernement', 'Immobilier', 'Sable & Carrières', 'Infrastructure']

const IMG = {
  route1:   'https://images.unsplash.com/photo-1766409873595-b75388463ce8?w=800&h=600&fit=crop&auto=format',
  terr1:    'https://images.unsplash.com/photo-1630288214173-a119cf823388?w=800&h=600&fit=crop&auto=format',
  gouv1:    'https://images.unsplash.com/photo-1644778055925-cf45809c2c17?w=800&h=600&fit=crop&auto=format',
  immo1:    'https://images.unsplash.com/photo-1783260606348-bb2deaa215a3?w=800&h=600&fit=crop&auto=format',
  sable1:   'https://images.unsplash.com/photo-1783578990149-8b91589a7b2c?w=800&h=600&fit=crop&auto=format',
  infra1:   'https://images.unsplash.com/photo-1630288214117-5ebf6c9de343?w=800&h=600&fit=crop&auto=format',
  terr2:    'https://images.unsplash.com/photo-1766409874040-d4b233e92089?w=800&h=600&fit=crop&auto=format',
  infra2:   'https://images.unsplash.com/photo-1714829732336-a11bc5a5cfd5?w=800&h=600&fit=crop&auto=format',
  gouv2:    'https://images.unsplash.com/photo-1674758978719-6121d8fbefb4?w=800&h=600&fit=crop&auto=format',
}

const projects = [
  { title: 'Réhabilitation voirie Bayakh–Diender', cat: 'Routes', img: IMG.route1, year: '2024', client: 'Ministère des Infrastructures', region: 'Thiès' },
  { title: 'Terrassement zone industrielle Thiès', cat: 'Terrassement', img: IMG.terr1, year: '2023', client: 'Entreprise privée BTP', region: 'Thiès' },
  { title: 'Voirie communale Commune Bayakh', cat: 'Gouvernement', img: IMG.gouv1, year: '2023', client: 'Mairie de Bayakh', region: 'Niayes' },
  { title: 'Lotissement résidentiel Diender', cat: 'Immobilier', img: IMG.immo1, year: '2022', client: 'Promoteur privé', region: 'Diender' },
  { title: 'Exploitation carrière sable Niayes', cat: 'Sable & Carrières', img: IMG.sable1, year: '2022', client: 'SMIT – Production propre', region: 'Niayes' },
  { title: 'Corridor industriel APIX', cat: 'Infrastructure', img: IMG.infra1, year: '2021', client: 'APIX Sénégal', region: 'Dakar' },
  { title: 'Aménagement terrain savane Niayes', cat: 'Terrassement', img: IMG.terr2, year: '2021', client: 'Collectivité locale', region: 'Niayes' },
  { title: 'Route d\'accès port de Dakar', cat: 'Infrastructure', img: IMG.infra2, year: '2020', client: 'Port Autonome de Dakar', region: 'Dakar' },
  { title: 'Cité administrative Thiès', cat: 'Gouvernement', img: IMG.gouv2, year: '2019', client: 'Gouvernement du Sénégal', region: 'Thiès' },
]

export default function Projects() {
  const [active, setActive] = useState('Tous')
  const filtered = active === 'Tous' ? projects : projects.filter(p => p.cat === active)

  return (
    <div className="pt-28" style={{ background: 'var(--smit-cream)' }}>
      {/* Hero */}
      <section className="py-24 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #022D15 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0"
          style={{ backgroundImage: `url(https://images.unsplash.com/photo-1762945050745-2d1c4235e0a7?w=1600&h=600&fit=crop&auto=format)`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.20 }} />
        <div className="absolute inset-0 african-pattern opacity-40" />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <div className="text-4xl mb-4">🏗️</div>
          <p className="text-[#E8C97A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>
            Notre portfolio
          </p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
            Nos Projets
          </h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto">
            500+ projets réalisés à travers le Sénégal — des routes gouvernementales
            aux carrières de sable en passant par l'immobilier résidentiel.
          </p>
        </div>
      </section>

      {/* Filtre */}
      <section className="py-8 bg-white border-b border-[#E2E4DC] sticky top-16 lg:top-20 z-30">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="flex flex-wrap gap-3">
            {categories.map(c => (
              <button key={c} onClick={() => setActive(c)}
                className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all ${
                  active === c ? 'bg-[#0A7A3D] text-white shadow-green' : 'bg-[#F5F6F0] text-[#6B7264] hover:bg-[#E2E4DC]'
                }`}
                style={{ fontFamily: 'var(--font-label)' }}>
                {c}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Grille */}
      <section className="py-20" style={{ background: 'var(--smit-cream)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map(p => (
              <div key={p.title}
                className="bg-white rounded-3xl overflow-hidden shadow-premium hover:-translate-y-2 hover:shadow-warm transition-all duration-300 group">
                <div className="h-64 relative bg-[#0A7A3D]"
                  style={{ backgroundImage: `url(${p.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(212,168,83,0.05), rgba(2,29,15,0.40))' }} />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className="text-xs font-bold px-3 py-1.5 rounded-full text-[#022D15]"
                      style={{ background: 'linear-gradient(135deg, #E8C97A, #C7A54A)', fontFamily: 'var(--font-label)' }}>
                      {p.cat}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4">
                    <span className="text-xs bg-white/20 backdrop-blur-sm text-white font-bold px-2.5 py-1 rounded-full border border-white/25">
                      📍 {p.region}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-bold text-base text-[#1A1F14] mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{p.title}</h3>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#6B7264]">{p.client}</span>
                    <span className="text-[#0A7A3D] font-bold">{p.year}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-white text-center">
        <div className="max-w-2xl mx-auto px-6">
          <div className="text-4xl mb-4">🇸🇳</div>
          <h2 className="text-4xl font-extrabold text-[#1A1F14] mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
            Votre projet, notre expertise
          </h2>
          <p className="text-[#6B7264] text-lg mb-8">Rejoignez les 500+ projets réalisés avec succès par SMIT.</p>
          <Link to="/request-quote"
            className="inline-flex items-center gap-2 text-white font-bold px-10 py-5 rounded-full text-lg hover:scale-105 transition-all shadow-green"
            style={{ background: 'linear-gradient(135deg, #0A7A3D, #045A2A)' }}>
            Demander un devis <ArrowRight size={20} />
          </Link>
        </div>
      </section>
    </div>
  )
}
