import { Link } from 'react-router-dom'
import { ArrowRight, Target, Eye, Heart, Leaf } from 'lucide-react'

const IMG = {
  chantier:   'https://images.unsplash.com/photo-1630288214173-a119cf823388?w=900&h=600&fit=crop&auto=format',
  savanna:    'https://images.unsplash.com/photo-1766409874040-d4b233e92089?w=900&h=600&fit=crop&auto=format',
  ouvriers:   'https://images.unsplash.com/photo-1644778055925-cf45809c2c17?w=900&h=600&fit=crop&auto=format',
  ingenieur:  'https://images.unsplash.com/photo-1601979107535-46367552bc25?w=900&h=600&fit=crop&auto=format',
  dunes:      'https://images.unsplash.com/photo-1783578990149-8b91589a7b2c?w=900&h=600&fit=crop&auto=format',
}

const values = [
  { icon: Target, title: 'Excellence', desc: 'Les normes les plus élevées dans chaque projet, chaque livraison, chaque interaction.' },
  { icon: Heart, title: 'Intégrité', desc: 'Honnêteté et transparence dans toutes nos relations commerciales et institutionnelles.' },
  { icon: Eye, title: 'Innovation', desc: 'Adoption des technologies et techniques modernes au service du BTP sénégalais.' },
  { icon: Leaf, title: 'Durabilité', desc: 'Exploitation responsable qui préserve les écosystèmes uniques de la zone des Niayes.' },
]

const milestones = [
  { year: '2004', event: 'Fondation de SMIT par M. Saliou Mbaye à Bayakh, Diender' },
  { year: '2007', event: 'Premier grand contrat gouvernemental d\'infrastructure routière' },
  { year: '2010', event: 'Ouverture de la première carrière de sable de dune dans les Niayes' },
  { year: '2014', event: 'Flotte étendue à 50+ engins lourds modernes' },
  { year: '2017', event: 'Lancement du pôle immobilier et vente de terrains' },
  { year: '2020', event: '500 projets réalisés à travers le Sénégal' },
  { year: '2024', event: 'Reconnaissance nationale — 1 000+ clients servis' },
]

export default function About() {
  return (
    <div className="pt-28" style={{ background: 'var(--smit-cream)' }}>
      {/* Hero */}
      <section className="py-24 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #022D15 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0"
          style={{ backgroundImage: `url(${IMG.savanna})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.18 }} />
        <div className="absolute inset-0 african-pattern opacity-50" />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 mb-6 px-5 py-2.5 rounded-full"
            style={{ background: 'rgba(212,168,83,0.18)', border: '1px solid rgba(212,168,83,0.35)' }}>
            <span className="text-lg">🇸🇳</span>
            <span className="text-[#E8C97A] text-xs font-bold tracking-widest uppercase" style={{ fontFamily: 'var(--font-label)' }}>
              Entreprise sénégalaise · Bayakh, Niayes
            </span>
          </div>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
            À propos de SMIT
          </h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto leading-relaxed">
            Leader sénégalais du terrassement, des carrières de sable, de la location d'engins lourds
            et de l'immobilier — enraciné dans la zone des Niayes, rayonnant sur tout le Sénégal.
          </p>
        </div>
      </section>

      {/* Notre histoire */}
      <section className="py-24 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="rounded-3xl overflow-hidden aspect-video bg-[#0A7A3D]"
                style={{ backgroundImage: `url(${IMG.chantier})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(212,168,83,0.10), rgba(2,29,15,0.20))' }} />
              </div>
              {/* Badge Niayes */}
              <div className="absolute -bottom-5 -left-5 bg-[#0A7A3D] text-white px-5 py-3 rounded-2xl shadow-green text-sm font-bold">
                🏔️ Zone des Niayes · Sénégal
              </div>
            </div>
            <div>
              <div className="section-divider mb-6" />
              <p className="text-[#0A7A3D] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
                Notre histoire
              </p>
              <h2 className="text-4xl font-extrabold text-[#1A1F14] mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                Nés de la terre
                <span className="block text-[#0A7A3D]">des Niayes</span>
              </h2>
              <p className="text-[#6B7264] leading-relaxed mb-4">
                Fondée en 2004 par M. Saliou Mbaye au cœur de Bayakh, Diender, SMIT est née d'une vision simple
                mais ambitieuse : exploiter les ressources naturelles de la zone des Niayes avec professionnalisme
                et les mettre au service du développement du Sénégal.
              </p>
              <p className="text-[#6B7264] leading-relaxed mb-4">
                Vingt ans plus tard, SMIT est l'un des acteurs de référence dans le terrassement, l'exploitation
                de sable de dune, la location d'engins lourds et l'immobilier — servant les institutions publiques,
                les grandes entreprises de BTP et les particuliers à travers tout le pays.
              </p>
              <p className="text-[#6B7264] leading-relaxed mb-6">
                Notre ancrage sénégalais est notre force : nous connaissons le terrain, nous parlons la langue
                de nos clients et nous partageons leur ambition pour un Sénégal moderne et prospère.
              </p>
              <Link to="/ceo" className="inline-flex items-center gap-2 text-[#0A7A3D] font-bold hover:gap-4 transition-all">
                Découvrir notre PDG <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Valeurs */}
      <section className="py-24" style={{ background: 'var(--smit-cream)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="text-center mb-14">
            <div className="section-divider mx-auto mb-6" />
            <h2 className="text-4xl font-extrabold text-[#1A1F14]" style={{ fontFamily: 'var(--font-heading)' }}>
              Nos valeurs fondamentales
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map(v => (
              <div key={v.title}
                className="bg-white rounded-3xl p-8 border border-[#E2E4DC] hover:border-[#0A7A3D] hover:shadow-green transition-all group text-center">
                <div className="w-16 h-16 rounded-2xl bg-[#F5F6F0] group-hover:bg-[#0A7A3D] flex items-center justify-center mx-auto mb-6 transition-colors">
                  <v.icon size={28} className="text-[#0A7A3D] group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-[#1A1F14] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{v.title}</h3>
                <p className="text-[#6B7264] text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24 bg-white">
        <div className="max-w-[900px] mx-auto px-6 lg:px-10">
          <div className="text-center mb-14">
            <div className="section-divider mx-auto mb-6" />
            <h2 className="text-4xl font-extrabold text-[#1A1F14]" style={{ fontFamily: 'var(--font-heading)' }}>
              20 ans d'histoire
            </h2>
          </div>
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-px bg-[#E2E4DC]" />
            <div className="space-y-8">
              {milestones.map((m) => (
                <div key={m.year} className="flex gap-6 items-start group">
                  <div className="flex-shrink-0 w-16 h-16 rounded-full bg-white border-2 border-[#0A7A3D] group-hover:bg-[#0A7A3D] flex items-center justify-center z-10 transition-colors shadow-green">
                    <span className="text-[#0A7A3D] group-hover:text-white text-xs font-bold transition-colors" style={{ fontFamily: 'var(--font-label)' }}>
                      {m.year.slice(2)}
                    </span>
                  </div>
                  <div className="flex-1 pb-6">
                    <div className="text-[#C7A54A] font-bold text-sm mb-1" style={{ fontFamily: 'var(--font-label)' }}>{m.year}</div>
                    <p className="text-[#6B7264] text-sm leading-relaxed bg-[#F5F6F0] rounded-2xl px-5 py-4 border border-[#E2E4DC] hover:border-[#0A7A3D] transition-colors">
                      {m.event}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 text-center relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #022D15, #0A7A3D)' }}>
        <div className="absolute inset-0 african-pattern opacity-50" />
        <div className="max-w-2xl mx-auto px-6 relative z-10">
          <div className="text-4xl mb-4">🇸🇳</div>
          <h2 className="text-4xl font-extrabold text-white mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
            Faites confiance à SMIT
          </h2>
          <p className="text-white/70 text-lg mb-8">
            L'entreprise sénégalaise de référence pour tous vos projets de construction et d'immobilier.
          </p>
          <Link to="/contact"
            className="inline-flex items-center gap-2 font-bold px-10 py-5 rounded-full text-lg hover:scale-105 transition-all"
            style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)', color: '#022D15' }}>
            Nous contacter <ArrowRight size={20} />
          </Link>
        </div>
      </section>
    </div>
  )
}
