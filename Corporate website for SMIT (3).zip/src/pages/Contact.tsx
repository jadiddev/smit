import { useState } from 'react'
import { Phone, Mail, MapPin, Clock, MessageCircle, Globe, Share2 } from 'lucide-react'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="pt-28">
      {/* Hero */}
      <section className="py-24 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #033D1C 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <p className="text-[#C7A54A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>Get In Touch</p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Contact SMIT</h1>
          <p className="text-white/70 text-xl max-w-2xl mx-auto">We're here to help. Reach out to discuss your project, request a quote, or get information about our services.</p>
        </div>
      </section>

      {/* Contact grid */}
      <section className="py-20 bg-[#F7F8FA]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Info panel */}
            <div className="lg:col-span-1 space-y-6">
              {/* Contact cards */}
              {[
                { icon: MapPin, title: 'Headquarters', info: 'Bayakh, Diender, Région de Thiès, Sénégal', sub: '' },
                { icon: Phone, title: 'Phone', info: '+221 77 000 0000', sub: 'Mon–Sat 08:00 – 18:00' },
                { icon: Mail, title: 'Email', info: 'contact@smit-senegal.com', sub: 'Response within 24h' },
                { icon: MessageCircle, title: 'WhatsApp', info: '+221 77 000 0000', sub: 'Quick responses' },
              ].map(c => (
                <div key={c.title} className="bg-white rounded-2xl p-6 border border-[#E8EAF0] hover:border-[#0A7A3D] hover:shadow-green transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-11 h-11 rounded-xl bg-[#0A7A3D]/10 flex items-center justify-center flex-shrink-0">
                      <c.icon size={20} className="text-[#0A7A3D]" />
                    </div>
                    <div>
                      <div className="font-bold text-[#222222] text-sm mb-0.5" style={{ fontFamily: 'var(--font-heading)' }}>{c.title}</div>
                      <div className="text-[#0A7A3D] text-sm font-medium">{c.info}</div>
                      {c.sub && <div className="text-[#6B7280] text-xs mt-0.5">{c.sub}</div>}
                    </div>
                  </div>
                </div>
              ))}

              {/* Hours */}
              <div className="bg-white rounded-2xl p-6 border border-[#E8EAF0]">
                <div className="flex items-center gap-3 mb-4">
                  <Clock size={18} className="text-[#0A7A3D]" />
                  <span className="font-bold text-[#222222] text-sm" style={{ fontFamily: 'var(--font-heading)' }}>Business Hours</span>
                </div>
                <div className="space-y-2 text-sm">
                  {[
                    { day: 'Monday – Friday', time: '08:00 – 18:00' },
                    { day: 'Saturday', time: '08:00 – 14:00' },
                    { day: 'Sunday', time: 'Closed' },
                  ].map(h => (
                    <div key={h.day} className="flex justify-between">
                      <span className="text-[#6B7280]">{h.day}</span>
                      <span className={`font-medium ${h.time === 'Closed' ? 'text-red-400' : 'text-[#0A7A3D]'}`}>{h.time}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Social */}
              <div className="bg-white rounded-2xl p-6 border border-[#E8EAF0]">
                <p className="font-bold text-[#222222] text-sm mb-4" style={{ fontFamily: 'var(--font-heading)' }}>Follow Us</p>
                <div className="flex gap-3">
                  {[Globe, Share2, MessageCircle].map((Icon, i) => (
                    <a key={i} href="#" className="w-10 h-10 rounded-full border border-[#E8EAF0] flex items-center justify-center hover:bg-[#0A7A3D] hover:border-[#0A7A3D] transition-all group">
                      <Icon size={16} className="text-[#6B7280] group-hover:text-white transition-colors" />
                    </a>
                  ))}
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-2 bg-white rounded-3xl p-8 lg:p-12 border border-[#E8EAF0] shadow-premium">
              {submitted ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-16">
                  <div className="text-6xl mb-6">✅</div>
                  <h3 className="text-2xl font-bold text-[#0A7A3D] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Message Sent!</h3>
                  <p className="text-[#6B7280]">Thank you for contacting SMIT. Our team will respond within 24 hours.</p>
                  <button onClick={() => setSubmitted(false)} className="mt-6 text-[#0A7A3D] font-bold text-sm hover:underline">Send another message</button>
                </div>
              ) : (
                <>
                  <h2 className="text-2xl font-extrabold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Send Us a Message</h2>
                  <p className="text-[#6B7280] text-sm mb-8">Fill out the form and our team will get back to you promptly.</p>
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Full Name *</label>
                        <input required type="text" placeholder="Your full name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                          className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Email *</label>
                        <input required type="email" placeholder="your@email.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                          className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Phone</label>
                        <input type="tel" placeholder="+221 77 000 0000" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                          className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Subject</label>
                        <input type="text" placeholder="How can we help?" value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                          className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-[#222222] mb-2" style={{ fontFamily: 'var(--font-label)' }}>Message *</label>
                      <textarea required rows={6} placeholder="Describe your project or inquiry in detail..." value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                        className="w-full border border-[#E8EAF0] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#0A7A3D] transition-colors resize-none" />
                    </div>
                    <button type="submit" className="w-full bg-[#0A7A3D] text-white font-bold py-4 rounded-xl hover:bg-[#045A2A] transition-colors text-base shadow-green">
                      Send Message
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="h-96 bg-[#E8EAF0] relative">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1566438480900-0609be27a4be?w=1400&h=400&fit=crop&auto=format)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'grayscale(30%)',
          }}
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, transparent, rgba(3,61,28,0.5))' }} />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-white rounded-2xl p-6 shadow-2xl flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-[#0A7A3D] flex items-center justify-center flex-shrink-0">
              <MapPin size={18} className="text-white" />
            </div>
            <div>
              <div className="font-bold text-[#222222] text-sm" style={{ fontFamily: 'var(--font-heading)' }}>SMIT Headquarters</div>
              <div className="text-[#6B7280] text-xs">Bayakh, Diender, Thiès, Sénégal</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
