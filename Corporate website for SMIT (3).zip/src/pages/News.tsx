import { Link } from 'react-router-dom'
import { ArrowRight, Calendar, Tag } from 'lucide-react'

const articles = [
  {
    title: 'SMIT Completes Major Highway Rehabilitation in Thiès Region',
    category: 'Infrastructure',
    date: 'June 15, 2025',
    excerpt: 'SMIT successfully completed a 12km highway rehabilitation project connecting Bayakh to the national road network, significantly improving connectivity for thousands of residents.',
    img: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=500&fit=crop&auto=format',
    featured: true,
  },
  {
    title: 'New Residential Lots Now Available in Bayakh Prestige Zone',
    category: 'Real Estate',
    date: 'May 28, 2025',
    excerpt: 'SMIT announces the release of premium residential lots in the sought-after Bayakh Prestige Zone, with full documentation and financing guidance available.',
    img: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=500&fit=crop&auto=format',
    featured: false,
  },
  {
    title: 'SMIT Fleet Expanded with 10 New Heavy Machines',
    category: 'Company News',
    date: 'April 10, 2025',
    excerpt: 'SMIT has expanded its modern fleet with the acquisition of 10 new heavy machines including excavators, wheel loaders, and dump trucks from Caterpillar and Komatsu.',
    img: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800&h=500&fit=crop&auto=format',
    featured: false,
  },
  {
    title: 'CEO Saliou Mbaye Speaks at Senegalese Industrial Forum 2025',
    category: 'Corporate',
    date: 'March 22, 2025',
    excerpt: 'Mr. Saliou Mbaye represented SMIT at the 2025 Senegalese Industrial Forum, sharing insights on construction industry growth and investment opportunities in the region.',
    img: 'https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?w=800&h=500&fit=crop&auto=format',
    featured: false,
  },
  {
    title: 'SMIT Launches Youth Employment Initiative in Diender',
    category: 'Community',
    date: 'February 5, 2025',
    excerpt: 'SMIT has launched a new youth training and employment initiative in Diender, providing technical skills training and guaranteed job placements for 50 young people.',
    img: 'https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?w=800&h=500&fit=crop&auto=format',
    featured: false,
  },
]

const catColor: Record<string, string> = {
  Infrastructure: 'bg-[#0A7A3D] text-white',
  'Real Estate': 'bg-[#C7A54A] text-[#033D1C]',
  'Company News': 'bg-[#222222] text-white',
  Corporate: 'bg-[#0A7A3D] text-white',
  Community: 'bg-[#0E9F6E] text-white',
}

export default function News() {
  const [featured, ...rest] = articles

  return (
    <div className="pt-28">
      <section className="py-24 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #033D1C 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <p className="text-[#C7A54A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>Latest Updates</p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>News & Announcements</h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto">Stay up to date with SMIT's latest projects, company news, and community initiatives.</p>
        </div>
      </section>

      <section className="py-20 bg-[#F7F8FA]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          {/* Featured */}
          <div className="bg-white rounded-3xl overflow-hidden shadow-premium flex flex-col lg:flex-row mb-12 group hover:shadow-green transition-all">
            <div className="lg:w-1/2 min-h-72 bg-[#0A7A3D]" style={{ backgroundImage: `url(${featured.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
            <div className="lg:w-1/2 p-10 lg:p-14 flex flex-col justify-center">
              <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full mb-4 self-start ${catColor[featured.category]}`} style={{ fontFamily: 'var(--font-label)' }}>
                <Tag size={12} />{featured.category}
              </span>
              <div className="flex items-center gap-2 text-[#6B7280] text-sm mb-4">
                <Calendar size={14} />{featured.date}
              </div>
              <h2 className="text-3xl font-extrabold text-[#222222] mb-4" style={{ fontFamily: 'var(--font-heading)' }}>{featured.title}</h2>
              <p className="text-[#6B7280] leading-relaxed mb-6">{featured.excerpt}</p>
              <Link to="/contact" className="inline-flex items-center gap-2 text-[#0A7A3D] font-bold hover:gap-4 transition-all">Read More <ArrowRight size={16} /></Link>
            </div>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {rest.map(a => (
              <div key={a.title} className="bg-white rounded-3xl overflow-hidden shadow-premium hover:-translate-y-1 hover:shadow-green transition-all group">
                <div className="h-48 bg-[#0A7A3D]" style={{ backgroundImage: `url(${a.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
                <div className="p-7">
                  <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full mb-3 ${catColor[a.category]}`} style={{ fontFamily: 'var(--font-label)' }}>
                    <Tag size={12} />{a.category}
                  </span>
                  <div className="flex items-center gap-2 text-[#6B7280] text-xs mb-3"><Calendar size={12} />{a.date}</div>
                  <h3 className="font-extrabold text-lg text-[#222222] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{a.title}</h3>
                  <p className="text-[#6B7280] text-sm leading-relaxed mb-4">{a.excerpt}</p>
                  <Link to="/contact" className="inline-flex items-center gap-1 text-[#0A7A3D] font-bold text-sm hover:gap-2 transition-all">Read More <ArrowRight size={14} /></Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
