import { Link } from 'react-router-dom'
import { ArrowRight, MapPin, CheckCircle, Maximize } from 'lucide-react'

const plots = [
  { title: 'Résidentiel Lot A – Bayakh', type: 'Residential', area: '600 m²', price: 'CFA 4,500,000', location: 'Bayakh Centre', status: 'Available', img: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop&auto=format' },
  { title: 'Commercial Plot – Route Nationale', type: 'Commercial', area: '1,200 m²', price: 'CFA 12,000,000', location: 'Route Nationale 2', status: 'Reserved', img: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600&h=400&fit=crop&auto=format' },
  { title: 'Agricultural Land – Diender Valley', type: 'Agricultural', area: '5 hectares', price: 'On Request', location: 'Diender Valley', status: 'Available', img: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop&auto=format' },
  { title: 'Industrial Zone – Thiès Est', type: 'Industrial', area: '3,000 m²', price: 'On Request', location: 'Thiès Est', status: 'Available', img: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=600&h=400&fit=crop&auto=format' },
  { title: 'Residential Lot B – Prestige', type: 'Residential', area: '400 m²', price: 'CFA 3,200,000', location: 'Bayakh Prestige Zone', status: 'Last Units', img: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=400&fit=crop&auto=format' },
  { title: 'Beachfront Development Land', type: 'Commercial', area: '8,000 m²', price: 'On Request', location: 'Côte de Thiès', status: 'Available', img: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=600&h=400&fit=crop&auto=format' },
]

const docFeatures = ['Title deed included', 'Legal clearance verified', 'Notarized contracts', 'Plot survey & maps', 'Investment advisory', 'Financing guidance']

export default function LandSales() {
  return (
    <div className="pt-28">
      <section className="py-24 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #033D1C 0%, #0A7A3D 100%)' }}>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <p className="text-[#C7A54A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>Land Sales</p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Prime Land for Sale</h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto">Residential, commercial, industrial, and agricultural plots with full documentation across Senegal's most strategic locations.</p>
        </div>
      </section>

      {/* Why buy through SMIT */}
      <section className="py-16 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="section-divider mb-6" />
              <h2 className="text-4xl font-extrabold text-[#222222] mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Buy Land with Confidence</h2>
              <p className="text-[#6B7280] leading-relaxed mb-8">Every plot sold by SMIT comes with secure legal documentation, verified title deeds, and professional guidance from our experienced real estate team. We make land buying in Senegal safe, simple, and transparent.</p>
              <div className="grid grid-cols-2 gap-3">
                {docFeatures.map(f => (
                  <div key={f} className="flex items-center gap-2 text-sm text-[#6B7280]">
                    <CheckCircle size={16} className="text-[#0A7A3D] flex-shrink-0" />
                    {f}
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-3xl overflow-hidden aspect-video bg-[#0A7A3D]" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&h=500&fit=crop&auto=format)', backgroundSize: 'cover', backgroundPosition: 'center' }} />
          </div>
        </div>
      </section>

      {/* Plots grid */}
      <section className="py-20 bg-[#F7F8FA]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {plots.map(p => (
              <div key={p.title} className="bg-white rounded-3xl overflow-hidden shadow-premium hover:-translate-y-2 hover:shadow-green transition-all duration-300 group">
                <div className="h-48 relative bg-[#0A7A3D]" style={{ backgroundImage: `url(${p.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                  <div className="absolute inset-0 bg-[#033D1C]/20 group-hover:bg-transparent transition-colors" />
                  <span className="absolute top-4 left-4 bg-[#C7A54A] text-[#033D1C] text-xs font-bold px-3 py-1.5 rounded-full" style={{ fontFamily: 'var(--font-label)' }}>{p.type}</span>
                  <span className={`absolute top-4 right-4 text-xs font-bold px-3 py-1.5 rounded-full ${p.status === 'Available' ? 'bg-[#0E9F6E] text-white' : p.status === 'Reserved' ? 'bg-[#222222] text-white' : 'bg-red-500 text-white'}`}>{p.status}</span>
                </div>
                <div className="p-6">
                  <h3 className="font-extrabold text-base text-[#222222] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{p.title}</h3>
                  <div className="flex items-center gap-2 text-sm text-[#6B7280] mb-1"><MapPin size={14} className="text-[#0A7A3D]" />{p.location}</div>
                  <div className="flex items-center gap-2 text-sm text-[#6B7280] mb-4"><Maximize size={14} className="text-[#0A7A3D]" />{p.area}</div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#0A7A3D] font-extrabold text-sm">{p.price}</span>
                    <Link to="/contact" className="flex items-center gap-1 text-[#0A7A3D] font-bold text-sm hover:gap-2 transition-all">Contact <ArrowRight size={14} /></Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
