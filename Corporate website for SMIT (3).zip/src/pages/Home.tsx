import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowRight, Play, Award, Shield, Users, Zap,
  Star, ChevronLeft, ChevronRight, Quote,
  Truck, Layers, Leaf, Heart, TrendingUp, MapPin,
  Package, Target, Building, Gauge, Clock, MessageCircle, Phone, CheckCircle
} from 'lucide-react'

/* ─────────────────────────────────────
   Constantes contact SMIT
───────────────────────────────────── */
const WHATSAPP_1 = '221765979880'
const WHATSAPP_2 = '221769934178'
const WA_MSG = encodeURIComponent('Bonjour, je souhaite commander du sable de dune auprès de SMIT. Merci de me contacter.')
const WA_URL_1 = `https://wa.me/${WHATSAPP_1}?text=${WA_MSG}`

/* ─────────────────────────────────────
   Hooks
───────────────────────────────────── */
function useCounter(target: number, duration = 2200, started: boolean) {
  const [count, setCount] = useState(0)
  useEffect(() => {
    if (!started) return
    let val = 0
    const step = target / (duration / 16)
    const t = setInterval(() => {
      val += step
      if (val >= target) { setCount(target); clearInterval(t) }
      else setCount(Math.floor(val))
    }, 16)
    return () => clearInterval(t)
  }, [target, duration, started])
  return count
}

function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true) }, { threshold })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [threshold])
  return { ref, inView }
}

/* ─────────────────────────────────────
   Images Unsplash – Scènes africaines
───────────────────────────────────── */
const IMG = {
  /* Paysages / chantiers africains */
  excavateurCoucher:  'https://images.unsplash.com/photo-1653315917834-04a6d84e132e?w=1920&h=1080&fit=crop&auto=format',
  poussiereCoucher:   'https://images.unsplash.com/photo-1762945050745-2d1c4235e0a7?w=1920&h=1080&fit=crop&auto=format',
  dunesOrange:        'https://images.unsplash.com/photo-1783578990149-8b91589a7b2c?w=1920&h=1080&fit=crop&auto=format',
  enginJaune:         'https://images.unsplash.com/photo-1630288214117-5ebf6c9de343?w=1920&h=1080&fit=crop&auto=format',
  savannaTraces:      'https://images.unsplash.com/photo-1766409873595-b75388463ce8?w=1600&h=900&fit=crop&auto=format',
  savannaDoree:       'https://images.unsplash.com/photo-1766409874040-d4b233e92089?w=1600&h=900&fit=crop&auto=format',
  /* Sable / carrières */
  dunesRipples:       'https://images.unsplash.com/photo-1775240087130-133c9886482a?w=1200&h=800&fit=crop&auto=format',
  dunesCoucher:       'https://images.unsplash.com/photo-1783579192602-7d8082f042a0?w=1200&h=800&fit=crop&auto=format',
  dunesAerien:        'https://images.unsplash.com/photo-1546034353-c8d3534c20fc?w=1200&h=800&fit=crop&auto=format',
  dunesPastel:        'https://images.unsplash.com/photo-1763535299644-d9e88f344e6f?w=1200&h=800&fit=crop&auto=format',
  camionsDirt:        'https://images.unsplash.com/photo-1714829732336-a11bc5a5cfd5?w=1200&h=800&fit=crop&auto=format',
  excavateurOrange:   'https://images.unsplash.com/photo-1630288214173-a119cf823388?w=1200&h=800&fit=crop&auto=format',
  /* Travailleurs africains */
  ouvriersHardHat:    'https://images.unsplash.com/photo-1644778055925-cf45809c2c17?w=900&h=700&fit=crop&auto=format',
  ingenierRouge:      'https://images.unsplash.com/photo-1601979107535-46367552bc25?w=900&h=700&fit=crop&auto=format',
  ouvriersVest:       'https://images.unsplash.com/photo-1729843823577-40db41a5e8c9?w=900&h=700&fit=crop&auto=format',
  /* Immobilier / villes africaines */
  villeAfrica:        'https://images.unsplash.com/photo-1783260606348-bb2deaa215a3?w=1200&h=800&fit=crop&auto=format',
  buildingAfrique:    'https://images.unsplash.com/photo-1674758978719-6121d8fbefb4?w=900&h=700&fit=crop&auto=format',
  chantierGrue:       'https://images.unsplash.com/photo-1707410148802-fe08fe956398?w=900&h=700&fit=crop&auto=format',
}

/* ─────────────────────────────────────
   Hero cinématique
───────────────────────────────────── */
const heroSlides = [
  { img: IMG.excavateurCoucher, title: 'Bâtir le Sénégal', sub: 'de demain', accent: 'avec excellence' },
  { img: IMG.poussiereCoucher, title: 'La terre, notre', sub: 'territoire', accent: 'notre fierté' },
  { img: IMG.dunesOrange, title: 'Le sable des Niayes', sub: 'au service du BTP', accent: 'sénégalais' },
  { img: IMG.enginJaune, title: 'Une flotte moderne', sub: 'au cœur du', accent: 'Sénégal' },
]

function Hero() {
  const [cur, setCur] = useState(0)
  const [showVideo, setShowVideo] = useState(false)
  const len = heroSlides.length

  useEffect(() => {
    const t = setInterval(() => setCur(c => (c + 1) % len), 6000)
    return () => clearInterval(t)
  }, [len])

  const s = heroSlides[cur]

  return (
    <section className="relative h-screen min-h-[700px] flex items-center overflow-hidden">
      {/* Slides */}
      {heroSlides.map((slide, i) => (
        <div
          key={i}
          className="absolute inset-0 transition-opacity duration-[1400ms]"
          style={{ opacity: i === cur ? 1 : 0, backgroundImage: `url(${slide.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
        />
      ))}

      {/* Overlays */}
      <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(2,29,15,0.90) 0%, rgba(10,122,61,0.45) 55%, rgba(181,128,58,0.25) 100%)' }} />
      {/* African geometric texture */}
      <div className="absolute inset-0 african-pattern opacity-60" />
      {/* Warm luminous vignette */}
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 70% 50%, rgba(212,168,83,0.12) 0%, transparent 65%)' }} />

      {/* Content */}
      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10 pt-28 w-full">
        <div className="max-w-3xl">
          {/* Badge sénégalais */}
          <div className="inline-flex items-center gap-2.5 mb-8 px-5 py-2.5 rounded-full border"
            style={{ background: 'rgba(212,168,83,0.15)', borderColor: 'rgba(212,168,83,0.35)', backdropFilter: 'blur(8px)' }}>
            <span className="text-lg">🇸🇳</span>
            <span className="text-[#D4B96A] text-xs font-bold tracking-[0.25em] uppercase" style={{ fontFamily: 'var(--font-label)' }}>
              Entreprise Sénégalaise de Confiance · Bayakh, Niayes
            </span>
          </div>

          <h1 className="text-5xl md:text-6xl lg:text-[4.5rem] font-extrabold text-white leading-[1.04] mb-5"
            style={{ fontFamily: 'var(--font-heading)', textShadow: '0 2px 20px rgba(0,0,0,0.4)' }}>
            {s.title}
            <span className="block" style={{
              background: 'linear-gradient(135deg, #E8C97A 0%, #C7A54A 50%, #0E9F6E 100%)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
            }}>
              {s.sub}
            </span>
            <span className="block text-white/80 text-4xl md:text-5xl lg:text-6xl italic font-light">
              {s.accent}
            </span>
          </h1>

          <p className="text-white/70 text-lg lg:text-xl leading-relaxed mb-10 max-w-2xl">
            SMIT – leader de l'exploitation de sable de dune, du terrassement, de la location d'engins
            et de l'immobilier dans la zone des Niayes et au Sénégal.
          </p>

          <div className="flex flex-wrap gap-4">
            <a href={WA_URL_1} target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 font-bold px-8 py-4 rounded-full text-base transition-all hover:scale-105 shadow-2xl"
              style={{ background: '#25D366', color: 'white', fontFamily: 'var(--font-label)', boxShadow: '0 8px 28px rgba(37,211,102,0.38)' }}>
              <MessageCircle size={20} /> Commander du sable
            </a>
            <a href="tel:+221765979880"
              className="inline-flex items-center gap-2.5 font-bold px-8 py-4 rounded-full text-base transition-all hover:scale-105"
              style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)', color: '#022D15', fontFamily: 'var(--font-label)' }}>
              <Phone size={18} /> Appeler maintenant
            </a>
            <Link to="/services"
              className="inline-flex items-center gap-2 border border-white/25 text-white font-semibold px-6 py-4 rounded-full text-base hover:bg-white/10 transition-all"
              style={{ backdropFilter: 'blur(8px)' }}>
              Nos Services
            </Link>
          </div>
        </div>
      </div>

      {/* Slide nav */}
      <div className="absolute bottom-36 left-6 lg:left-10 z-10 flex gap-2">
        {heroSlides.map((_, i) => (
          <button key={i} onClick={() => setCur(i)}
            className={`h-1 rounded-full transition-all duration-400 ${i === cur ? 'w-10 bg-[#C7A54A]' : 'w-2 bg-white/30'}`} />
        ))}
      </div>

      {/* Stats */}
      <div className="absolute bottom-0 left-0 right-0 z-10">
        <StatBar />
      </div>

      {showVideo && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4" onClick={() => setShowVideo(false)}>
          <div className="w-full max-w-4xl aspect-video bg-[#022D15] rounded-2xl flex items-center justify-center">
            <div className="text-center text-white opacity-50"><Play size={72} className="mx-auto mb-4" /><p>Vidéo corporate à venir</p></div>
          </div>
        </div>
      )}
    </section>
  )
}

function StatCounter({ target, suffix, label }: { target: number; suffix: string; label: string }) {
  const { ref, inView } = useInView(0.1)
  const count = useCounter(target, 2000, inView)
  return (
    <div ref={ref} className="text-center px-4 py-6 border-r border-white/10 last:border-0">
      <div className="text-3xl lg:text-4xl font-extrabold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
        {count}{suffix}
      </div>
      <div className="text-[#D4B96A] text-xs font-bold uppercase tracking-widest mt-1" style={{ fontFamily: 'var(--font-label)' }}>
        {label}
      </div>
    </div>
  )
}

function StatBar() {
  return (
    <div style={{ background: 'rgba(2,29,15,0.88)', backdropFilter: 'blur(12px)', borderTop: '1px solid rgba(212,168,83,0.15)' }}>
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-2 md:grid-cols-5">
          <StatCounter target={20} suffix="+" label="Ans d'expérience" />
          <StatCounter target={500} suffix="+" label="Projets réalisés" />
          <StatCounter target={1000} suffix="+" label="Clients satisfaits" />
          <StatCounter target={100} suffix="+" label="Engins modernes" />
          <div className="col-span-2 md:col-span-1 text-center px-4 py-6">
            <div className="text-3xl lg:text-4xl font-extrabold text-white" style={{ fontFamily: 'var(--font-heading)' }}>24/7</div>
            <div className="text-[#D4B96A] text-xs font-bold uppercase tracking-widest mt-1" style={{ fontFamily: 'var(--font-label)' }}>Support</div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────
   SECTION : Leader sable des Niayes
───────────────────────────────────── */
function SectionLeaderSable() {
  const { ref, inView } = useInView()
  return (
    <section className="relative overflow-hidden py-0">
      {/* Photo panoramique plein largeur */}
      <div className="relative h-[70vh] min-h-[520px]">
        <div className="absolute inset-0" style={{ backgroundImage: `url(${IMG.dunesRipples})`, backgroundSize: 'cover', backgroundPosition: 'center 60%' }} />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(2,29,15,0.94) 0%, rgba(2,29,15,0.70) 50%, rgba(181,128,58,0.35) 100%)' }} />
        <div className="absolute inset-0 african-pattern opacity-40" />

        <div className="relative z-10 h-full max-w-[1400px] mx-auto px-6 lg:px-10 flex items-center">
          <div ref={ref} className="max-w-2xl">
            <div className="section-divider-sand mb-6" />
            <div className="inline-flex items-center gap-2 mb-4 px-4 py-2 rounded-full"
              style={{ background: 'rgba(212,168,83,0.20)', border: '1px solid rgba(212,168,83,0.35)' }}>
              <span className="w-2 h-2 rounded-full bg-[#D4A853] animate-pulse" />
              <span className="text-[#E8C97A] text-xs font-bold tracking-widest uppercase" style={{ fontFamily: 'var(--font-label)' }}>
                Zone des Niayes · Bayakh · Diender
              </span>
            </div>

            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-extrabold text-white leading-tight mb-6"
              style={{ fontFamily: 'var(--font-heading)' }}>
              Leader de la vente de
              <span className="block" style={{
                background: 'linear-gradient(135deg, #E8C97A, #C7A54A)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
              }}>
                sable de dune
              </span>
              dans les Niayes
            </h2>

            <p className="text-white/70 text-lg leading-relaxed mb-8">
              SMIT extrait et fournit du sable de dune de haute qualité pour les entreprises de BTP,
              les promoteurs immobiliers, les collectivités locales et les particuliers à travers tout le Sénégal.
              Notre carrière, implantée au cœur de la zone des Niayes, garantit un approvisionnement
              fiable, rapide et conforme aux normes de construction.
            </p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              {[
                { icon: Truck, label: 'Livraison rapide', sub: 'Sur chantier en 24h' },
                { icon: Layers, label: 'Volume garanti', sub: 'Petites à grandes commandes' },
                { icon: Shield, label: 'Sable certifié', sub: 'Qualité contrôlée' },
                { icon: MapPin, label: 'Zone couverte', sub: 'Toute la région de Thiès' },
              ].map(item => (
                <div key={item.label}
                  className={`flex items-center gap-3 transition-all duration-500 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
                  style={{ transitionDelay: '200ms' }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: 'rgba(212,168,83,0.25)', border: '1px solid rgba(212,168,83,0.4)' }}>
                    <item.icon size={18} className="text-[#E8C97A]" />
                  </div>
                  <div>
                    <div className="text-white font-bold text-sm" style={{ fontFamily: 'var(--font-heading)' }}>{item.label}</div>
                    <div className="text-white/50 text-xs">{item.sub}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <Link to="/services"
                className="inline-flex items-center gap-2 font-bold px-7 py-3.5 rounded-full transition-all hover:scale-105"
                style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)', color: '#022D15' }}>
                Commander du sable <ArrowRight size={16} />
              </Link>
              <Link to="/contact"
                className="inline-flex items-center gap-2 border border-white/25 text-white font-semibold px-7 py-3.5 rounded-full hover:bg-white/10 transition-all">
                Nous contacter
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Clients cibles */}
      <div style={{ background: '#022D15', borderTop: '1px solid rgba(212,168,83,0.2)' }}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-8">
          <div className="flex flex-wrap items-center gap-6 justify-center">
            <span className="text-[#D4B96A] text-xs font-bold uppercase tracking-widest" style={{ fontFamily: 'var(--font-label)' }}>
              Nos clients :
            </span>
            {['Entreprises BTP', 'Promoteurs immobiliers', 'Collectivités locales', 'Maçons et artisans', 'Particuliers', 'Industriels'].map(c => (
              <span key={c}
                className="px-4 py-2 rounded-full text-sm font-medium text-white/70 border border-white/10 hover:border-[#C7A54A] hover:text-[#E8C97A] transition-colors cursor-default"
                style={{ fontFamily: 'var(--font-label)' }}>
                {c}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Galerie – Nos carrières de sable
───────────────────────────────────── */
const carGallery = [
  { img: IMG.dunesCoucher, title: 'Vue aérienne – carrière principale', tag: 'Carrières' },
  { img: IMG.excavateurOrange, title: 'Pelle hydraulique en action', tag: 'Exploitation' },
  { img: IMG.camionsDirt, title: 'Chargement camions bennes', tag: 'Logistique' },
  { img: IMG.dunesAerien, title: 'Zones de stockage sable', tag: 'Stockage' },
  { img: IMG.dunesPastel, title: 'Dunes des Niayes', tag: 'Ressources' },
  { img: IMG.enginJaune, title: 'Bulldozer nivellement', tag: 'Equipements' },
  { img: IMG.savannaTraces, title: 'Routes traversant les dunes', tag: 'Infrastructure' },
  { img: IMG.poussiereCoucher, title: 'Coucher de soleil sur chantier', tag: 'Atmosphère' },
]

function GalerieCarrieres() {
  const { ref, inView } = useInView()
  return (
    <section className="py-24" style={{ background: 'var(--smit-cream)' }}>
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div ref={ref} className="mb-14">
          <div className="section-divider-sand mb-6" />
          <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between gap-6">
            <div>
              <p className="text-[#B5803A] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
                📸 En images
              </p>
              <h2 className="text-4xl lg:text-5xl font-extrabold text-[#1A1F14] leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
                Nos carrières de sable
              </h2>
              <p className="text-[#6B7264] mt-3 text-lg max-w-xl">
                Découvrez nos sites d'exploitation dans la zone des Niayes — des carrières modernes
                opérées avec professionnalisme et respect de l'environnement.
              </p>
            </div>
            <Link to="/projects" className="inline-flex items-center gap-2 text-[#0A7A3D] font-bold hover:gap-4 transition-all flex-shrink-0">
              Voir tous les projets <ArrowRight size={18} />
            </Link>
          </div>
        </div>

        {/* Grille asymétrique */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {carGallery.map((item, i) => (
            <div
              key={item.title}
              className={`relative overflow-hidden group cursor-pointer rounded-2xl ${
                i === 0 ? 'col-span-2 row-span-2' : ''
              } ${inView ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}
              style={{ height: i === 0 ? '440px' : '210px', transition: 'all 0.6s ease', transitionDelay: `${i * 60}ms` }}
            >
              <div className="absolute inset-0 transition-transform duration-700 group-hover:scale-110"
                style={{ backgroundImage: `url(${item.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
              {/* Warm overlay africain */}
              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(2,29,15,0.85) 0%, rgba(181,128,58,0.10) 50%, transparent 70%)' }} />
              {/* Tag */}
              <div className="absolute top-3 left-3">
                <span className="px-3 py-1.5 rounded-full text-xs font-bold text-[#022D15]"
                  style={{ background: 'linear-gradient(135deg, #E8C97A, #C7A54A)', fontFamily: 'var(--font-label)' }}>
                  {item.tag}
                </span>
              </div>
              {/* Caption */}
              <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                <p className="text-white font-bold text-sm leading-snug" style={{ fontFamily: 'var(--font-heading)' }}>
                  {item.title}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Services
───────────────────────────────────── */
const servicesList = [
  { icon: '🏗️', title: 'Terrassement', desc: 'Excavation, nivellement, déblais et remblais pour tous types de projets au Sénégal.', img: IMG.excavateurOrange },
  { icon: '🚜', title: 'Location d\'engins', desc: 'Bulldozers, pelles hydrauliques, chargeuses — avec chauffeur expérimenté inclus.', img: IMG.enginJaune },
  { icon: '🛣️', title: 'Préparation de routes', desc: 'Mise en forme de chaussée, compactage et drainage pour infrastructure routière.', img: IMG.savannaTraces },
  { icon: '⛏️', title: 'Sable de dune – Niayes', desc: 'Extraction et vente de sable de qualité pour BTP, immobilier et particuliers.', img: IMG.dunesCoucher },
  { icon: '🏢', title: 'Immobilier', desc: 'Terrains viabilisés, projets résidentiels et foncier avec documentation complète.', img: IMG.villeAfrica },
  { icon: '⚙️', title: 'Génie civil', desc: 'Études techniques, drainage, fondations et aménagement de terrain.', img: IMG.chantierGrue },
]

function ServicesSection() {
  const { ref, inView } = useInView()
  return (
    <section className="py-24" style={{ background: '#F5F6F0' }}>
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div ref={ref} className="text-center mb-16">
          <div className="section-divider mx-auto mb-6" />
          <p className="text-[#0A7A3D] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
            Nos expertises
          </p>
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#1A1F14] leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
            Nos Services Phares
          </h2>
          <p className="text-[#6B7264] mt-4 text-lg max-w-2xl mx-auto">
            Du terrassement à l'immobilier, SMIT offre des solutions industrielles complètes
            aux entreprises, collectivités et particuliers du Sénégal.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicesList.map((s, i) => (
            <div
              key={s.title}
              className={`bg-white rounded-3xl overflow-hidden shadow-premium hover:-translate-y-2 hover:shadow-warm transition-all duration-500 group ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="h-52 relative bg-[#0A7A3D]" style={{ backgroundImage: `url(${s.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(212,168,83,0.05), rgba(2,29,15,0.45))' }} />
                <div className="absolute top-4 left-4 w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                  style={{ background: 'rgba(212,168,83,0.25)', backdropFilter: 'blur(6px)', border: '1px solid rgba(212,168,83,0.4)' }}>
                  {s.icon}
                </div>
              </div>
              <div className="p-7">
                <h3 className="text-lg font-bold text-[#1A1F14] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{s.title}</h3>
                <p className="text-[#6B7264] text-sm leading-relaxed mb-5">{s.desc}</p>
                <Link to="/services" className="inline-flex items-center gap-1.5 text-[#0A7A3D] font-bold text-sm hover:gap-3 transition-all">
                  En savoir plus <ArrowRight size={15} />
                </Link>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-12">
          <Link to="/services"
            className="inline-flex items-center gap-2 bg-[#0A7A3D] text-white font-bold px-8 py-4 rounded-full hover:bg-[#045A2A] transition-all hover:scale-105 shadow-green">
            Voir tous nos services <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Pourquoi choisir SMIT
───────────────────────────────────── */
const whyCards = [
  { icon: Award, title: '20+ ans d\'expérience', desc: 'Deux décennies d\'excellence dans le terrassement, les carrières et l\'immobilier au Sénégal.' },
  { icon: Truck, title: 'Flotte imposante', desc: '100+ engins modernes : bulldozers, pelles, chargeuses, camions bennes — toujours disponibles.' },
  { icon: Users, title: 'Équipe sénégalaise', desc: 'Des ingénieurs, techniciens et opérateurs sénégalais formés aux standards internationaux.' },
  { icon: Zap, title: 'Livraison express', desc: 'Sable et engins livrés rapidement sur vos chantiers, partout dans la région de Thiès.' },
  { icon: Shield, title: 'Qualité constante', desc: 'Contrôle qualité rigoureux à chaque étape — matériaux certifiés et travaux conformes.' },
  { icon: Heart, title: 'Entreprise locale', desc: 'SMIT est fière de ses racines sénégalaises et de son engagement envers le développement local.' },
]

function WhyChooseSection() {
  const { ref, inView } = useInView()
  return (
    <section className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image ouvriers africains */}
          <div className="relative order-2 lg:order-1">
            <div className="rounded-3xl overflow-hidden aspect-[4/3] bg-[#0A7A3D]"
              style={{ backgroundImage: `url(${IMG.ouvriersHardHat})`, backgroundSize: 'cover', backgroundPosition: 'center top' }}>
              <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(212,168,83,0.08), rgba(2,29,15,0.25))' }} />
            </div>
            {/* Badge flottant */}
            <div className="absolute -bottom-6 -right-4 bg-white rounded-2xl p-5 shadow-warm border border-[#E2E4DC]">
              <div className="text-[#0A7A3D] font-extrabold text-3xl leading-none" style={{ fontFamily: 'var(--font-heading)' }}>🇸🇳</div>
              <div className="text-[#1A1F14] font-bold text-xs mt-1" style={{ fontFamily: 'var(--font-label)' }}>100% Sénégalais</div>
            </div>
            {/* Deuxième photo */}
            <div className="absolute -top-6 -left-6 w-32 h-32 rounded-2xl overflow-hidden border-4 border-white shadow-premium">
              <div style={{ backgroundImage: `url(${IMG.ingenierRouge})`, backgroundSize: 'cover', backgroundPosition: 'center', width: '100%', height: '100%' }} />
            </div>
          </div>

          {/* Contenu */}
          <div ref={ref} className="order-1 lg:order-2">
            <div className="section-divider mb-6" />
            <p className="text-[#0A7A3D] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
              Pourquoi SMIT ?
            </p>
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#1A1F14] leading-tight mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              L'excellence sénégalaise
              <span className="block text-[#0A7A3D]">à votre service</span>
            </h2>
            <p className="text-[#6B7264] text-lg leading-relaxed mb-8">
              SMIT n'est pas simplement un prestataire — c'est un partenaire de confiance qui connaît
              le terrain sénégalais, ses défis et ses opportunités, et qui s'engage pour la réussite
              de chaque projet.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {whyCards.map((c, i) => (
                <div
                  key={c.title}
                  className={`p-5 rounded-2xl border border-[#E2E4DC] hover:border-[#0A7A3D] hover:shadow-green transition-all duration-300 group engagement-card ${
                    inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  }`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="w-10 h-10 rounded-xl bg-[#F5F6F0] flex items-center justify-center mb-3 transition-all duration-300 engagement-icon">
                    <c.icon size={20} className="text-[#0A7A3D]" />
                  </div>
                  <h4 className="font-bold text-[#1A1F14] text-sm mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{c.title}</h4>
                  <p className="text-[#6B7264] text-xs leading-relaxed">{c.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Nos Engagements
───────────────────────────────────── */
const engagements = [
  { emoji: '✅', title: 'Qualité des matériaux', desc: 'Sable et matériaux de construction rigoureusement sélectionnés et contrôlés.' },
  { emoji: '⏱️', title: 'Respect des délais', desc: 'Nous honorons nos engagements — livraisons et travaux dans les délais convenus.' },
  { emoji: '🦺', title: 'Sécurité sur les chantiers', desc: 'Protocoles de sécurité stricts pour la protection de nos équipes et de nos clients.' },
  { emoji: '🌿', title: 'Protection de l\'environnement', desc: 'Exploitation responsable qui préserve la biodiversité unique de la zone des Niayes.' },
  { emoji: '🌍', title: 'Développement local', desc: 'Nous investissons dans les infrastructures et les ressources humaines de la région.' },
  { emoji: '👷', title: 'Création d\'emplois', desc: 'Priorité à l\'emploi local — nous formons et embauchons les jeunes de Bayakh et Diender.' },
  { emoji: '⭐', title: 'Satisfaction client', desc: 'Chaque client mérite un accompagnement personnalisé et des résultats qui dépassent ses attentes.' },
]

function EngagementsSection() {
  const { ref, inView } = useInView()
  return (
    <section className="py-24" style={{ background: 'var(--smit-cream)' }}>
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div ref={ref} className="text-center mb-16">
          <div className="section-divider mx-auto mb-6" />
          <p className="text-[#0A7A3D] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
            Notre philosophie
          </p>
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#1A1F14]" style={{ fontFamily: 'var(--font-heading)' }}>
            Nos Engagements
          </h2>
          <p className="text-[#6B7264] mt-4 text-lg max-w-2xl mx-auto">
            Chez SMIT, chaque engagement est une promesse — envers nos clients, nos employés,
            nos communautés et notre territoire.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {engagements.slice(0, 4).map((e, i) => (
            <div
              key={e.title}
              className={`bg-white rounded-3xl p-7 border border-[#E2E4DC] hover:border-[#0A7A3D] hover:shadow-green transition-all duration-400 group text-center ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="text-4xl mb-4">{e.emoji}</div>
              <h3 className="font-bold text-[#1A1F14] text-base mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{e.title}</h3>
              <p className="text-[#6B7264] text-sm leading-relaxed">{e.desc}</p>
            </div>
          ))}
        </div>

        {/* Row 2 – 3 centered */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mt-5 max-w-3xl mx-auto">
          {engagements.slice(4).map((e, i) => (
            <div
              key={e.title}
              className={`bg-white rounded-3xl p-7 border border-[#E2E4DC] hover:border-[#0A7A3D] hover:shadow-green transition-all duration-400 group text-center ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${(i + 4) * 80}ms` }}
            >
              <div className="text-4xl mb-4">{e.emoji}</div>
              <h3 className="font-bold text-[#1A1F14] text-base mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{e.title}</h3>
              <p className="text-[#6B7264] text-sm leading-relaxed">{e.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : CEO teaser
───────────────────────────────────── */
function CEOTeaser() {
  return (
    <section className="py-24 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #022D15 0%, #0A7A3D 60%, #B5803A 100%)' }}>
      <div className="absolute inset-0 african-pattern opacity-60" />
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 80% 50%, rgba(212,168,83,0.18) 0%, transparent 60%)' }} />
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="absolute -inset-4 rounded-[40px] opacity-20" style={{ background: 'linear-gradient(135deg, #C7A54A, #0A7A3D)' }} />
            <div className="relative rounded-3xl overflow-hidden aspect-[3/4] max-w-sm mx-auto lg:mx-0 bg-[#033D1C]"
              style={{ backgroundImage: `url(${IMG.ouvriersVest})`, backgroundSize: 'cover', backgroundPosition: 'center top' }}>
              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, #022D15 0%, transparent 55%)' }} />
              <div className="absolute bottom-6 left-6 right-6">
                <div className="text-[#E8C97A] text-xs tracking-widest uppercase font-bold mb-1" style={{ fontFamily: 'var(--font-label)' }}>Fondateur & PDG</div>
                <div className="text-white text-2xl font-extrabold" style={{ fontFamily: 'var(--font-heading)' }}>Saliou Mbaye</div>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 rounded-2xl p-5 shadow-2xl text-center"
              style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)' }}>
              <div className="text-[#022D15] font-extrabold text-3xl" style={{ fontFamily: 'var(--font-heading)' }}>20+</div>
              <div className="text-[#022D15] text-xs font-bold uppercase tracking-widest mt-1">Années<br />Vision</div>
            </div>
          </div>

          <div>
            <div className="w-12 h-1 rounded-full mb-6" style={{ background: 'linear-gradient(90deg, #E8C97A, #C7A54A)' }} />
            <p className="text-[#E8C97A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>Leadership</p>
            <h2 className="text-4xl lg:text-5xl font-extrabold text-white leading-tight mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Un entrepreneur
              <span className="block" style={{
                background: 'linear-gradient(135deg, #E8C97A, #C7A54A)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
              }}>
                visionnaire sénégalais
              </span>
            </h2>
            <p className="text-white/70 text-lg leading-relaxed mb-6">
              M. Saliou Mbaye est l'un des entrepreneurs les plus respectés de la zone Bayakh–Diender.
              Pionnier de l'exploitation industrielle de sable de dune au Sénégal, il a su bâtir
              SMIT en une entreprise reconnue par les institutions publiques et les acteurs privés.
            </p>
            <div className="bg-white/8 backdrop-blur-sm border border-white/15 rounded-2xl p-6 mb-8">
              <Quote size={22} className="text-[#E8C97A] mb-3" />
              <p className="text-white/90 italic text-lg leading-relaxed">
                "Nous ne déplaçons pas seulement la terre. Nous construisons l'avenir du Sénégal,
                pierre par pierre, sac de sable par sac de sable."
              </p>
              <p className="text-[#E8C97A] font-bold text-sm mt-4" style={{ fontFamily: 'var(--font-label)' }}>
                — Saliou Mbaye, PDG · SMIT
              </p>
            </div>
            <Link to="/ceo"
              className="inline-flex items-center gap-2 font-bold px-8 py-4 rounded-full hover:scale-105 transition-all"
              style={{ background: 'linear-gradient(135deg, #C7A54A, #D4A853)', color: '#022D15' }}>
              Lire la biographie complète <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Carte zones desservies
───────────────────────────────────── */
function ZonesDesservies() {
  const zones = [
    { name: 'Bayakh', status: 'Siège', color: '#0A7A3D' },
    { name: 'Diender', status: 'Zone principale', color: '#0A7A3D' },
    { name: 'Thiès', status: 'Couverture totale', color: '#C7A54A' },
    { name: 'Dakar', status: 'Livraisons régulières', color: '#C7A54A' },
    { name: 'Mbour', status: 'Zone desservie', color: '#6B7264' },
    { name: 'Tivaouane', status: 'Zone desservie', color: '#6B7264' },
    { name: 'Rufisque', status: 'Zone desservie', color: '#6B7264' },
    { name: 'Kaolack', status: 'Sur commande', color: '#B5803A' },
  ]
  return (
    <section className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="section-divider-sand mb-6" />
            <p className="text-[#B5803A] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>Couverture géographique</p>
            <h2 className="text-4xl lg:text-5xl font-extrabold text-[#1A1F14] mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Zones desservies
              <span className="block text-[#0A7A3D]">par SMIT</span>
            </h2>
            <p className="text-[#6B7264] text-lg leading-relaxed mb-8">
              Depuis nos carrières de Bayakh et Diender, SMIT livre du sable de dune et déploie
              ses engins sur tous les chantiers de la région de Thiès, de Dakar et au-delà.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {zones.map(z => (
                <div key={z.name} className="flex items-center gap-3 p-3.5 rounded-xl border border-[#E2E4DC] hover:border-[#0A7A3D] transition-colors">
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: z.color }} />
                  <div>
                    <div className="font-bold text-[#1A1F14] text-sm" style={{ fontFamily: 'var(--font-heading)' }}>{z.name}</div>
                    <div className="text-[#6B7264] text-xs">{z.status}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Carte stylisée */}
          <div className="relative">
            <div className="rounded-3xl overflow-hidden aspect-square relative"
              style={{ backgroundImage: `url(${IMG.savannaDoree})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
              <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(2,29,15,0.70), rgba(212,168,83,0.30))' }} />
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 p-8">
                <div className="text-6xl">🗺️</div>
                <div className="text-white text-center">
                  <div className="font-extrabold text-2xl mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Zone des Niayes</div>
                  <div className="text-white/70 text-sm">Bayakh · Diender · Thiès</div>
                </div>
                {/* Points animés */}
                {[
                  { x: '30%', y: '40%', label: 'Bayakh' },
                  { x: '45%', y: '55%', label: 'Diender' },
                  { x: '60%', y: '35%', label: 'Thiès' },
                ].map(p => (
                  <div key={p.label} className="absolute flex flex-col items-center" style={{ left: p.x, top: p.y, transform: 'translate(-50%,-50%)' }}>
                    <div className="w-4 h-4 rounded-full bg-[#C7A54A] border-2 border-white animate-ping absolute" />
                    <div className="w-4 h-4 rounded-full bg-[#C7A54A] border-2 border-white relative z-10" />
                    <div className="mt-1 bg-white/90 text-[#022D15] text-xs font-bold px-2 py-0.5 rounded-full" style={{ fontFamily: 'var(--font-label)' }}>
                      {p.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 bg-[#0A7A3D] text-white px-6 py-3 rounded-full font-bold text-sm shadow-green whitespace-nowrap">
              📦 Livraison sur tout le Sénégal
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Notre impact communautaire
───────────────────────────────────── */
const impacts = [
  { num: '500+', label: 'Emplois créés', desc: 'Priorité à l\'emploi local dans la zone de Bayakh et Diender.' },
  { num: '15+', label: 'Communautés soutenues', desc: 'Aide directe aux villages et quartiers de la zone des Niayes.' },
  { num: '3', label: 'Écoles soutenues', desc: 'Financement de bourses et d\'infrastructures scolaires locales.' },
  { num: '100%', label: 'Sénégalais', desc: 'Équipe 100% sénégalaise, fière de ses racines et de son territoire.' },
]

function ImpactSection() {
  const { ref, inView } = useInView()
  return (
    <section className="py-24 relative overflow-hidden" style={{ background: '#1A1F14' }}>
      <div className="absolute inset-0"
        style={{ backgroundImage: `url(${IMG.savannaDoree})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.12 }} />
      <div className="absolute inset-0 african-pattern opacity-30" />

      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10">
        <div ref={ref} className="text-center mb-16">
          <div className="section-divider-sand mx-auto mb-6" />
          <p className="text-[#E8C97A] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
            Responsabilité sociale
          </p>
          <h2 className="text-4xl lg:text-5xl font-extrabold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
            Notre impact dans
            <span className="block" style={{
              background: 'linear-gradient(135deg, #E8C97A, #C7A54A)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
            }}>
              la communauté
            </span>
          </h2>
          <p className="text-white/60 mt-4 text-lg max-w-2xl mx-auto">
            Au-delà du business, SMIT investit dans les hommes, les femmes et les communautés
            de Bayakh, Diender et de la zone des Niayes.
          </p>
        </div>

        {/* Stats numériques */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {impacts.map((item, i) => (
            <div
              key={item.label}
              className={`text-center p-8 rounded-3xl border transition-all duration-500 ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(212,168,83,0.2)',
                transitionDelay: `${i * 100}ms`,
              }}
            >
              <div className="text-4xl lg:text-5xl font-extrabold mb-2" style={{
                fontFamily: 'var(--font-heading)',
                background: 'linear-gradient(135deg, #E8C97A, #C7A54A)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
              }}>
                {item.num}
              </div>
              <div className="text-white font-bold text-sm mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{item.label}</div>
              <div className="text-white/50 text-xs">{item.desc}</div>
            </div>
          ))}
        </div>

        {/* Actions CSR */}
        <div className="grid lg:grid-cols-2 gap-8">
          <div className="rounded-3xl overflow-hidden relative" style={{ minHeight: '280px' }}>
            <div className="absolute inset-0" style={{ backgroundImage: `url(${IMG.ouvriersHardHat})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
            <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(2,29,15,0.85), rgba(2,29,15,0.45))' }} />
            <div className="relative z-10 p-8 h-full flex flex-col justify-end">
              <h3 className="text-white font-extrabold text-2xl mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Emploi & Formation</h3>
              <p className="text-white/70 text-sm leading-relaxed">
                SMIT forme et emploie en priorité les jeunes de la zone des Niayes,
                leur offrant des compétences techniques reconnues.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {[
              { icon: Leaf, title: 'Environnement', desc: 'Exploitation durable et reboisement dans la zone des Niayes.' },
              { icon: TrendingUp, title: 'Économie locale', desc: 'Approvisionnement local, partenariats avec les artisans et PME sénégalaises.' },
              { icon: Heart, title: 'Accompagnement jeunes', desc: 'Programme de mentorat et d\'insertion professionnelle pour les jeunes diplômés.' },
            ].map(a => (
              <div key={a.title} className="flex items-start gap-4 p-5 rounded-2xl" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(212,168,83,0.15)' }}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(212,168,83,0.20)' }}>
                  <a.icon size={18} className="text-[#E8C97A]" />
                </div>
                <div>
                  <div className="text-white font-bold text-sm mb-0.5" style={{ fontFamily: 'var(--font-heading)' }}>{a.title}</div>
                  <div className="text-white/55 text-xs leading-relaxed">{a.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Nos Partenaires (premium)
───────────────────────────────────── */
const partnerCategories = [
  {
    label: 'Institutions publiques', icon: Building,
    partners: ['Ministère des Infrastructures', 'AGEROUTE', 'ONAS', 'APIX Sénégal'],
  },
  {
    label: 'Collectivités territoriales', icon: MapPin,
    partners: ['Mairie de Bayakh', 'Commune de Diender', 'Commune de Thiès', 'Région de Thiès'],
  },
  {
    label: 'Entreprises BTP', icon: Layers,
    partners: ['Partenaire BTP A', 'Partenaire BTP B', 'Partenaire BTP C', 'Partenaire BTP D'],
  },
  {
    label: 'Promoteurs immobiliers', icon: Target,
    partners: ['Promoteur A', 'Promoteur B', 'Promoteur C', 'Promoteur D'],
  },
  {
    label: 'Banques & finances', icon: Gauge,
    partners: ['SGBS', 'CBAO', 'BHS', 'Ecobank'],
  },
  {
    label: 'Fournisseurs techniques', icon: Package,
    partners: ['Fournisseur A', 'Fournisseur B', 'Fournisseur C', 'Fournisseur D'],
  },
]

function PartenairesSection() {
  const { ref, inView } = useInView()
  return (
    <section className="py-24" style={{ background: '#F5F6F0' }}>
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div ref={ref} className="text-center mb-16">
          <div className="section-divider mx-auto mb-6" />
          <p className="text-[#0A7A3D] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
            Réseau de confiance
          </p>
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#1A1F14]" style={{ fontFamily: 'var(--font-heading)' }}>
            Nos Partenaires
          </h2>
          <p className="text-[#6B7264] mt-4 text-lg max-w-2xl mx-auto">
            SMIT collabore avec les institutions les plus importantes du Sénégal —
            des collectivités aux banques, en passant par les grandes entreprises de BTP.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {partnerCategories.map((cat, i) => (
            <div
              key={cat.label}
              className={`bg-white rounded-3xl p-7 border border-[#E2E4DC] hover:border-[#0A7A3D] hover:shadow-green transition-all duration-400 group ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              {/* Catégorie header */}
              <div className="flex items-center gap-3 mb-5 pb-4 border-b border-[#E2E4DC]">
                <div className="w-10 h-10 rounded-xl bg-[#F5F6F0] group-hover:bg-[#0A7A3D] flex items-center justify-center transition-colors">
                  <cat.icon size={18} className="text-[#0A7A3D] group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-bold text-[#1A1F14] text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
                  {cat.label}
                </h3>
              </div>

              {/* Logos placeholders élégants */}
              <div className="grid grid-cols-2 gap-3">
                {cat.partners.map((p) => (
                  <div key={p}
                    className="h-14 rounded-xl border-2 border-dashed border-[#E2E4DC] flex items-center justify-center text-[#6B7264] text-xs font-medium hover:border-[#C7A54A] hover:text-[#B5803A] transition-colors text-center px-2"
                    style={{ fontFamily: 'var(--font-label)' }}>
                    {p}
                  </div>
                ))}
              </div>

              <p className="text-[#6B7264] text-xs mt-4 text-center italic">
                Logos officiels à venir
              </p>
            </div>
          ))}
        </div>

        {/* Partenaires animés */}
        <div className="mt-14 overflow-hidden rounded-2xl border border-[#E2E4DC] bg-white">
          <div className="p-5 border-b border-[#E2E4DC] text-center">
            <p className="text-[#6B7264] text-xs font-bold uppercase tracking-widest" style={{ fontFamily: 'var(--font-label)' }}>
              Ils nous font confiance
            </p>
          </div>
          <div className="overflow-hidden py-5">
            <div className="partners-track flex gap-10 items-center" style={{ width: 'max-content' }}>
              {[
                'Ministère Infrastructure', 'AGEROUTE', 'Mairie Bayakh', 'ONAS', 'APIX Sénégal',
                'Région de Thiès', 'SGBS Bank', 'CBAO', 'BHS', 'Ecobank', 'Mairie Diender', 'Port de Dakar',
                'Ministère Infrastructure', 'AGEROUTE', 'Mairie Bayakh', 'ONAS', 'APIX Sénégal',
                'Région de Thiès', 'SGBS Bank', 'CBAO', 'BHS', 'Ecobank', 'Mairie Diender', 'Port de Dakar',
              ].map((p, i) => (
                <div key={i}
                  className="flex-shrink-0 px-6 py-3 bg-[#F5F6F0] rounded-xl border border-[#E2E4DC] text-sm font-bold text-[#6B7264] hover:text-[#0A7A3D] hover:border-[#0A7A3D] transition-colors whitespace-nowrap"
                  style={{ fontFamily: 'var(--font-label)' }}>
                  {p}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   SECTION : Témoignages – Ils nous font confiance
───────────────────────────────────── */
const testimonials = [
  {
    name: 'Ibrahima Diallo',
    title: 'Directeur Technique, Ministère des Infrastructures',
    text: 'SMIT a livré notre projet de voirie dans les délais, avec une qualité irréprochable. Leur connaissance du terrain sénégalais est un vrai avantage. Je recommande SMIT sans réserve.',
    rating: 5,
    img: IMG.ouvriersHardHat,
    flag: '🇸🇳',
  },
  {
    name: 'Mamadou Seck',
    title: 'PDG, Seck Construction & BTP',
    text: 'Les engins de SMIT sont en excellent état et les opérateurs sont professionnels. On loue régulièrement leur pelle hydraulique et leur bulldozer — fiabilité totale sur tous nos chantiers.',
    rating: 5,
    img: IMG.ingenierRouge,
    flag: '🇸🇳',
  },
  {
    name: 'Fatou Sarr',
    title: 'Promotrice immobilière, Dakar',
    text: 'Le sable de dune de SMIT est d\'une qualité constante. Livraison ponctuelle, quantités respectées et service commercial très réactif. C\'est notre fournisseur attitré pour tous nos projets.',
    rating: 5,
    img: IMG.ouvriersVest,
    flag: '🇸🇳',
  },
  {
    name: 'El Hadj Ndiaye',
    title: 'Maire, Commune de Bayakh',
    text: 'SMIT est une fierté pour Bayakh. M. Saliou Mbaye a non seulement bâti une entreprise exemplaire, mais il contribue activement au développement de notre communauté. C\'est un modèle.',
    rating: 5,
    img: IMG.ouvriersHardHat,
    flag: '🇸🇳',
  },
]

function TestimonialsSection() {
  const [idx, setIdx] = useState(0)
  const len = testimonials.length
  const t = testimonials[idx]

  return (
    <section className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="text-center mb-14">
          <div className="section-divider mx-auto mb-6" />
          <p className="text-[#0A7A3D] font-bold text-sm uppercase tracking-widest mb-3" style={{ fontFamily: 'var(--font-label)' }}>
            Ils nous font confiance
          </p>
          <h2 className="text-4xl lg:text-5xl font-extrabold text-[#1A1F14]" style={{ fontFamily: 'var(--font-heading)' }}>
            La voix de nos clients
          </h2>
        </div>

        <div className="max-w-3xl mx-auto">
          <div key={idx}
            className="rounded-3xl p-10 lg:p-14 text-center border shadow-premium"
            style={{ background: '#F5F6F0', borderColor: '#E2E4DC', animation: 'fadeIn 0.4s ease' }}>
            <div className="flex justify-center gap-1 mb-5">
              {Array.from({ length: t.rating }).map((_, i) => (
                <Star key={i} size={18} fill="#C7A54A" className="text-[#C7A54A]" />
              ))}
            </div>
            <div className="text-4xl mb-6">{t.flag}</div>
            <Quote size={28} className="text-[#0A7A3D] mx-auto mb-5" />
            <p className="text-[#1A1F14] text-xl leading-relaxed italic mb-8">"{t.text}"</p>
            <div className="flex items-center justify-center gap-4">
              <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-[#C7A54A] bg-[#0A7A3D]"
                style={{ backgroundImage: `url(${t.img})`, backgroundSize: 'cover', backgroundPosition: 'center top' }} />
              <div className="text-left">
                <div className="text-[#1A1F14] font-bold" style={{ fontFamily: 'var(--font-heading)' }}>{t.name}</div>
                <div className="text-[#B5803A] text-sm">{t.title}</div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-4 mt-8">
            <button onClick={() => setIdx(i => (i - 1 + len) % len)}
              className="w-12 h-12 rounded-full border border-[#E2E4DC] flex items-center justify-center text-[#6B7264] hover:bg-[#0A7A3D] hover:text-white hover:border-[#0A7A3D] transition-all">
              <ChevronLeft size={20} />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button key={i} onClick={() => setIdx(i)}
                  className={`h-1.5 rounded-full transition-all ${i === idx ? 'w-8 bg-[#0A7A3D]' : 'w-2 bg-[#E2E4DC]'}`} />
              ))}
            </div>
            <button onClick={() => setIdx(i => (i + 1) % len)}
              className="w-12 h-12 rounded-full border border-[#E2E4DC] flex items-center justify-center text-[#6B7264] hover:bg-[#0A7A3D] hover:text-white hover:border-[#0A7A3D] transition-all">
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   Commander du sable
───────────────────────────────────── */
const tarifs = [
  { capacite: '20 m³', prix: '25 000 FCFA', badge: '⭐ Populaire', highlight: true },
  { capacite: '17 m³', prix: '20 000 FCFA', badge: null, highlight: false },
  { capacite: '16 m³', prix: '15 000 FCFA', badge: null, highlight: false },
  { capacite: '8 m³',  prix: '5 000 FCFA',  badge: null, highlight: false },
]

function CommanderSable() {
  const { ref, inView } = useInView(0.12)

  return (
    <section ref={ref} id="commander-sable" className="py-24 relative overflow-hidden"
      style={{ background: 'linear-gradient(160deg, #022D15 0%, #033D1C 50%, #045A2A 100%)' }}>
      {/* Texture */}
      <div className="absolute inset-0 african-pattern opacity-50" />
      <div className="absolute inset-0" style={{ backgroundImage: `url(https://images.unsplash.com/photo-1783578990149-8b91589a7b2c?w=1920&h=1080&fit=crop&auto=format)`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.08 }} />
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 80% 50%, rgba(212,168,83,0.10) 0%, transparent 65%)' }} />

      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className={`text-center mb-16 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="inline-flex items-center gap-2.5 mb-5 px-5 py-2.5 rounded-full border"
            style={{ background: 'rgba(212,168,83,0.12)', borderColor: 'rgba(212,168,83,0.30)' }}>
            <span className="text-lg">🏜️</span>
            <span className="text-[#D4B96A] text-xs font-bold tracking-widest uppercase" style={{ fontFamily: 'var(--font-label)' }}>
              Sable de Dune · Niayes
            </span>
          </div>
          <h2 className="text-5xl lg:text-6xl font-extrabold text-white mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
            Commander du sable
          </h2>
          <p className="text-white/65 text-xl max-w-2xl mx-auto leading-relaxed">
            Livraison rapide de sable de dune de qualité supérieure directement sur vos chantiers.
            Disponible 7j/7 de <strong className="text-[#D4B96A]">07h à 19h</strong>.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Colonne gauche : tarifs + CTA */}
          <div className={`transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            {/* Tarifs */}
            <h3 className="text-[#E8C97A] font-bold text-sm tracking-widest uppercase mb-6 flex items-center gap-2" style={{ fontFamily: 'var(--font-label)' }}>
              <span className="w-8 h-px" style={{ background: 'var(--smit-gold)' }} /> Tableau des Tarifs
            </h3>
            <div className="space-y-3 mb-8">
              {tarifs.map((t) => (
                <div key={t.capacite}
                  className="flex items-center justify-between px-6 py-5 rounded-2xl transition-all group"
                  style={{
                    background: t.highlight
                      ? 'linear-gradient(135deg, rgba(199,165,74,0.22), rgba(212,168,83,0.12))'
                      : 'rgba(255,255,255,0.06)',
                    border: t.highlight ? '1.5px solid rgba(199,165,74,0.50)' : '1px solid rgba(255,255,255,0.10)',
                  }}>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: t.highlight ? 'rgba(199,165,74,0.22)' : 'rgba(255,255,255,0.07)' }}>
                      <Truck size={20} style={{ color: t.highlight ? '#C7A54A' : 'rgba(255,255,255,0.55)' }} />
                    </div>
                    <div>
                      <div className="text-white font-bold text-lg" style={{ fontFamily: 'var(--font-heading)' }}>{t.capacite}</div>
                      {t.badge && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                          style={{ background: 'rgba(199,165,74,0.25)', color: '#E8C97A', fontFamily: 'var(--font-label)' }}>
                          {t.badge}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-extrabold" style={{ color: t.highlight ? '#E8C97A' : 'white', fontFamily: 'var(--font-heading)' }}>
                      {t.prix}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Note tarifs */}
            <div className="flex items-start gap-3 px-5 py-4 rounded-xl mb-8"
              style={{ background: 'rgba(212,168,83,0.10)', border: '1px solid rgba(212,168,83,0.20)' }}>
              <CheckCircle size={16} className="text-[#C7A54A] flex-shrink-0 mt-0.5" />
              <p className="text-white/60 text-sm leading-relaxed">
                Les prix peuvent varier selon la zone de livraison. Contactez-nous pour obtenir un devis personnalisé.
              </p>
            </div>

            {/* Boutons commande */}
            <div className="space-y-3">
              <a href={WA_URL_1} target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 w-full py-5 rounded-2xl font-bold text-lg transition-all hover:scale-105 hover:shadow-2xl"
                style={{ background: '#25D366', color: 'white', fontFamily: 'var(--font-label)', boxShadow: '0 8px 32px rgba(37,211,102,0.35)' }}>
                <MessageCircle size={22} />
                Commander sur WhatsApp
              </a>
              <div className="grid grid-cols-2 gap-3">
                <a href="tel:+221765979880"
                  className="flex items-center justify-center gap-2 py-4 rounded-xl font-bold text-sm transition-all hover:scale-105"
                  style={{ background: 'rgba(255,255,255,0.09)', border: '1px solid rgba(255,255,255,0.15)', color: 'white', fontFamily: 'var(--font-label)' }}>
                  <Phone size={16} /> 76 597 98 80
                </a>
                <a href="tel:+221769934178"
                  className="flex items-center justify-center gap-2 py-4 rounded-xl font-bold text-sm transition-all hover:scale-105"
                  style={{ background: 'rgba(255,255,255,0.09)', border: '1px solid rgba(255,255,255,0.15)', color: 'white', fontFamily: 'var(--font-label)' }}>
                  <Phone size={16} /> 76 993 41 78
                </a>
              </div>
            </div>
          </div>

          {/* Colonne droite : horaires + livraison */}
          <div className={`transition-all duration-700 delay-200 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            {/* Horaires */}
            <div className="rounded-3xl p-8 mb-6"
              style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }}>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: 'linear-gradient(135deg, rgba(199,165,74,0.25), rgba(199,165,74,0.10))' }}>
                  <Clock size={22} style={{ color: '#C7A54A' }} />
                </div>
                <div>
                  <h3 className="text-white font-bold text-xl" style={{ fontFamily: 'var(--font-heading)' }}>Horaires d'ouverture</h3>
                  <p className="text-white/45 text-sm">Disponibles toute la semaine</p>
                </div>
              </div>
              <div className="flex items-center justify-between py-4 border-t border-white/10">
                <div>
                  <p className="text-white font-semibold text-base">Lundi — Dimanche</p>
                  <p className="text-white/50 text-sm">Toute la semaine, sans exception</p>
                </div>
                <div className="text-right">
                  <p className="text-[#E8C97A] font-extrabold text-2xl" style={{ fontFamily: 'var(--font-heading)' }}>07h – 19h</p>
                  <div className="flex items-center justify-end gap-1.5 mt-1">
                    <span className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />
                    <span className="text-[#25D366] text-xs font-bold">Ouvert maintenant</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Livraison */}
            <div className="rounded-3xl p-8"
              style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }}>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: 'linear-gradient(135deg, rgba(14,159,110,0.30), rgba(10,122,61,0.15))' }}>
                  <Truck size={22} style={{ color: '#0E9F6E' }} />
                </div>
                <div>
                  <h3 className="text-white font-bold text-xl" style={{ fontFamily: 'var(--font-heading)' }}>Livraison Rapide</h3>
                  <p className="text-white/45 text-sm">Sur toute la zone Niayes–Dakar–Thiès</p>
                </div>
              </div>
              {/* Image camion */}
              <div className="rounded-2xl overflow-hidden mb-5 h-36"
                style={{ backgroundImage: `url(https://images.unsplash.com/photo-1714829732336-a11bc5a5cfd5?w=800&h=400&fit=crop&auto=format)`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <div className="h-full w-full flex items-end p-4"
                  style={{ background: 'linear-gradient(to top, rgba(2,45,21,0.75), transparent)' }}>
                  <span className="text-white text-xs font-bold">Flotte SMIT · Camions de livraison sable 🏜️</span>
                </div>
              </div>
              <p className="text-white/65 text-sm leading-relaxed mb-5">
                SMIT assure la livraison rapide de sable de dune sur vos chantiers grâce à une flotte
                de camions performants. Nous livrons les particuliers, les entreprises et les professionnels du BTP.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {['Particuliers', 'Entreprises BTP', 'Livraison Dakar', 'Livraison Thiès'].map(item => (
                  <div key={item} className="flex items-center gap-2 text-sm text-white/70">
                    <CheckCircle size={14} className="text-[#0E9F6E] flex-shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   CTA finale
───────────────────────────────────── */
function CTABanner() {
  return (
    <section className="py-20 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #C7A54A 0%, #D4A853 40%, #B5803A 100%)' }}>
      <div className="absolute inset-0 african-pattern opacity-40" />
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, rgba(2,29,15,0.10) 0%, transparent 70%)' }} />
      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10 text-center">
        <div className="text-5xl mb-6">🇸🇳</div>
        <h2 className="text-4xl lg:text-5xl font-extrabold text-[#022D15] mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
          Démarrez votre projet avec SMIT
        </h2>
        <p className="text-[#022D15]/70 text-xl mb-10 max-w-2xl mx-auto">
          Terrassement, sable de dune, location d'engins, immobilier —
          l'entreprise sénégalaise de référence est à votre service.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <a href={WA_URL_1} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-2.5 font-bold px-8 py-5 rounded-full text-lg hover:scale-105 transition-all shadow-2xl"
            style={{ background: '#25D366', color: 'white', fontFamily: 'var(--font-label)', boxShadow: '0 8px 32px rgba(37,211,102,0.40)' }}>
            <MessageCircle size={20} /> Commander du sable
          </a>
          <a href="tel:+221765979880"
            className="flex items-center gap-2.5 bg-[#022D15] text-white font-bold px-8 py-5 rounded-full text-lg hover:bg-[#0A7A3D] transition-all hover:scale-105 shadow-2xl">
            <Phone size={20} /> Appeler maintenant
          </a>
          <Link to="/request-quote"
            className="bg-white/30 backdrop-blur-sm border-2 border-[#022D15]/25 text-[#022D15] font-bold px-8 py-5 rounded-full text-lg hover:bg-white/50 transition-all">
            Demander un devis
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────────────────────
   Export
───────────────────────────────────── */
export default function Home() {
  return (
    <>
      <Hero />
      <SectionLeaderSable />
      <CommanderSable />
      <GalerieCarrieres />
      <ServicesSection />
      <WhyChooseSection />
      <ZonesDesservies />
      <EngagementsSection />
      <CEOTeaser />
      <ImpactSection />
      <PartenairesSection />
      <TestimonialsSection />
      <CTABanner />
    </>
  )
}
