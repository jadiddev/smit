import { Link } from 'react-router-dom'
import { ArrowRight, MapPin, Maximize } from 'lucide-react'

const properties = [
  {
    title: 'Bayakh Prestige Villas',
    type: 'Residential',
    location: 'Bayakh, Diender',
    area: '250 – 400 m²',
    price: 'On Request',
    status: 'Available',
    img: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=600&fit=crop&auto=format',
  },
  {
    title: 'Diender Commercial Hub',
    type: 'Commercial',
    location: 'Diender, Thiès',
    area: '500 – 2,000 m²',
    price: 'On Request',
    status: 'Coming Soon',
    img: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800&h=600&fit=crop&auto=format',
  },
  {
    title: 'Thiès Industrial Park Plots',
    type: 'Industrial',
    location: 'Thiès Region',
    area: '1,000 – 5,000 m²',
    price: 'On Request',
    status: 'Available',
    img: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=800&h=600&fit=crop&auto=format',
  },
  {
    title: 'Saly Coastal Residences',
    type: 'Residential',
    location: 'Saly, Mbour',
    area: '150 – 300 m²',
    price: 'On Request',
    status: 'Pre-sale',
    img: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&h=600&fit=crop&auto=format',
  },
  {
    title: 'Agricultural Investment Land',
    type: 'Agricultural',
    location: 'Diender, Senegal',
    area: '2 – 50 hectares',
    price: 'On Request',
    status: 'Available',
    img: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&h=600&fit=crop&auto=format',
  },
  {
    title: 'Bayakh Executive Lots',
    type: 'Residential',
    location: 'Bayakh, Diender',
    area: '400 – 800 m²',
    price: 'On Request',
    status: 'Limited',
    img: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=600&fit=crop&auto=format',
  },
]

const typeColors: Record<string, string> = {
  Residential: 'bg-[#0E9F6E] text-white',
  Commercial: 'bg-[#C7A54A] text-[#033D1C]',
  Industrial: 'bg-[#222222] text-white',
  Agricultural: 'bg-[#0A7A3D] text-white',
}

const statusColors: Record<string, string> = {
  Available: 'text-[#0E9F6E]',
  'Coming Soon': 'text-[#C7A54A]',
  'Pre-sale': 'text-[#0A7A3D]',
  Limited: 'text-red-500',
}

export default function RealEstate() {
  return (
    <div className="pt-28">
      <section
        className="py-24 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #033D1C 0%, #0A7A3D 100%)' }}
      >
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative z-10 text-center">
          <p className="text-[#C7A54A] font-bold text-sm uppercase tracking-widest mb-4" style={{ fontFamily: 'var(--font-label)' }}>Real Estate</p>
          <h1 className="text-5xl lg:text-6xl font-extrabold text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Premium Properties</h1>
          <p className="text-white/70 text-xl max-w-3xl mx-auto">
            Invest in Senegal's fastest-growing real estate market. SMIT offers residential, commercial, industrial, and agricultural properties with full legal documentation.
          </p>
        </div>
      </section>

      <section className="py-20 bg-[#F7F8FA]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map(p => (
              <div key={p.title} className="bg-white rounded-3xl overflow-hidden shadow-premium hover:-translate-y-2 hover:shadow-green transition-all duration-300 group">
                <div className="h-56 relative bg-[#0A7A3D]" style={{ backgroundImage: `url(${p.img})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                  <div className="absolute inset-0 bg-[#033D1C]/20 group-hover:bg-[#033D1C]/10 transition-colors" />
                  <span className={`absolute top-4 left-4 text-xs font-bold px-3 py-1.5 rounded-full ${typeColors[p.type]}`} style={{ fontFamily: 'var(--font-label)' }}>{p.type}</span>
                </div>
                <div className="p-6">
                  <h3 className="font-extrabold text-lg text-[#222222] mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{p.title}</h3>
                  <div className="flex items-center gap-2 text-sm text-[#6B7280] mb-2">
                    <MapPin size={14} className="text-[#0A7A3D]" />
                    {p.location}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#6B7280] mb-4">
                    <Maximize size={14} className="text-[#0A7A3D]" />
                    {p.area}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-bold ${statusColors[p.status]}`}>● {p.status}</span>
                    <Link to="/contact" className="flex items-center gap-1 text-[#0A7A3D] font-bold text-sm hover:gap-2 transition-all">
                      Enquire <ArrowRight size={14} />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
